import logo from './logo.svg';
import './App.css';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import SearchBar from './Component/SearchBar';
import FlightForm from './Component/FlightForm';
import Holidays from './Component/Holidays';
import SelectRoom from './Component/SelectRoom';
import Room from './Component/Room';
import ViewAll from './Component/ViewAll'
import FlightDetail from './Component/FlightDetails'
import AboutFlight from './Component/AboutFlight'
import Demo from './Component/Demo';
import Footer from './Component/Footer'
import Navbar from './Component/Navbar'
import SelectHotelRoom from './Component/SelectHotelRoom';
// import BusMainSection from './Component/BusMainSection'
import Bus from './Component/Bus';
import RoundTrip from './Component/RoundTrip';



function App() {
  return (
    <>
      {/* <RoundTrip/> */}

      <Navbar />
      <Routes>
        <Route path="/" element={<FlightForm />} />
        <Route path="/hotels" element={<SearchBar />} />
        <Route path="/flight" element={<FlightForm />} />
        <Route path="/hotels:id" element={<SelectRoom />} />
        <Route path="/room:id" element={<Room />} />
        <Route path="/Hotel-SelectRoom:id" element={<Room />} />
        <Route path="/view:id" element={<ViewAll />} />
        <Route path="/holiday" element={<Holidays />} />
        <Route path="/flightSearch" element={<AboutFlight />} />
        <Route path="/flightSearch:id" element={<Demo />} />
        <Route path="/hotelList:id" element={<Demo />} />
        <Route path="/hotel:id" element={<SelectHotelRoom />} />
        <Route path="/demo:id" element={<Demo />} />
        <Route path="/busDetails" element={<Bus/>} />
        <Route path="*" element={<h1>Loading...</h1>} />
      </Routes>
      <Footer/>


    </>
  );
}

export default App;
