import React, { useState, useEffect } from "react";
import FlightSec from "./OneWayTrip";
import "./AboutFlight.css";
import SliderDate from "./SliderDate";
import { useNavigate } from 'react-router-dom'
import tabUtil from "./Tab";
import AboutFlightPopUp from "./AboutFlightPopUp";
import FlightJsonData from "./FlightJsonData";
import RoundTrip from "./RoundTrip";










function FlightDetails() {
  const navigate = useNavigate()

  const BookHotel = (e) => {
    navigate(`/flightSearch${e}`)
  }
  const [showdata, setShowdata] = useState(false);
  const [popUp, setpopUp] = useState(false);
  const [jsonData, setJsonData] = useState(FlightJsonData);
  console.log("🚀 ~ file: AboutFlight.js ~ line 21 ~ FlightDetails ~ jsonData", jsonData)
  const [waySelection, SetWaySelection] = useState(true)

  const [filterdata, setfilterdata] = useState('');
  const [filteredResults, setFilteredResults] = useState([]);

  // console.log(filteredResults, "filteredResults data");

  useEffect(() => {
    if (showdata) {
      document.getElementById('bydefaultTab').click();
    }
  }, [showdata])

  useEffect(() => {
    document.getElementById('defaultvalue').click();

  }, [])


  function handleCallTab(event, tabName) {
    var tab, btn;
    tab = document.getElementsByClassName("overview206");
    btn = document.getElementsByClassName("callTab");
    for (var i = 0; i < tab.length; i++) {
      tab[i].style.display = "none";
    }
    for (var j = 0; j < btn.length; j++) {
      btn[j].className = btn[j].className.replace(" active", "");
    }
    document.getElementById(tabName).style.display = "block";
    event.currentTarget.classList += " active";

  }

  function tabs2(event, tabName) {
    var tab, btn, activeClass;
    activeClass = 'activebtn';
    tab = document.getElementsByClassName('tabSec_22622');
    btn = document.getElementsByClassName('btnSec_12622');
    tabUtil(event, tabName, tab, btn, activeClass)

  }


  function showpopup() {
    setpopUp(!popUp)
    document.getElementById("hide").style.display = "none"
    document.getElementById("show").style.display = "block"
  }
  function hidepopup() {
    setpopUp(!popUp)
    document.getElementById("hide").style.display = "block"
    document.getElementById("show").style.display = "none"
  }

  // const DataFilter = (arr, query) => {
  //   return arr.filter(function (el) {
  //     return el.tolowerCase().indexOf(query.toLowerCase()) !== -1
  //   });

  // }

  // const FilterData = (e) => {
  //   const query = e;
  //   const filterDataReturn = jsonData.map((person1, index) => {
  //     person1.fareFlightSegment.map((fareFlightSegment) => {
  //       fareFlightSegment.flightSegmentsGroups.map((person3) => {
  //         person3.flightSegments.map((person4) => {
  //         return  person4.segments.filter((el) => el.carrier.name.toLowerCase().includes(query.toLowerCase()));
  //         })
  //       })
  //     })
  //   })

  //   console.log(filterDataReturn, ' it is your data ')

  //   if (filterDataReturn.lenght === 0) {
  //     setFilteredResults(false);
  //   }
  //   else {
  //     setFilteredResults(filterDataReturn);
  //   }
  // }

  function handlechange(e) {
    setfilterdata(e.target.value);
  }

  const [data, setdata] = useState(0)
  console.log(data,"button")

  return (
    <>
      <input type="input"
        value={filterdata}
        onChange={handlechange}
      />

      <div className="container my-4">
        <div className="hoteldata_6477">
          <div className="row">
            <div className="col-md-2 col-6 hoteldetail_14722 d-flex" style={{ borderRight: "1px solid gray" }}>
              <div className="hoteldetail_12722 mr-2">
                <p style={{ fontWeight: "700" }}>BLR</p>
                <span>Bangalore</span>
              </div>
              <div style={{ fontSize: "25px" }}>
                &rarr;
              </div>
              <div className="hoteldetail_12722 ml-2">
                <p style={{ fontWeight: "700" }}>BLR</p>
                <span>Bangalore</span>
              </div>
            </div>
            <div className="col-md-2 col-6 hoteldetail_14722" style={{ borderRight: "1px solid gray" }}>
              <div className="hoteldetail_12722">
                <p>Departure</p>
                <span>14 Jul’22 , Thursday</span>
              </div>
            </div>
            <div className="col-md-1 col-6 hoteldetail_14722" style={{ borderRight: "1px solid gray" }}>
              <div className="hoteldetail_12722">
                <p>Travellers</p>
                <span><b>01</b></span>
              </div>
            </div>
            <div className="col-md-2 col-6 hoteldetail_14722">
              <div className="hoteldetail_12722">
                <p>Travel Class</p>
                <span>Economy</span>
              </div>
            </div>
            <div className="col-md-5">
              <div style={{ display: "flex", flexDirection: "row", float: "right" }}>
                <section className="flightDet_23622" >
                  <div className='searchSec_22622'>
                    <span><i class="fa-solid fa-share-nodes"></i></span><span className='search_25622' id="hide" onClick={showpopup}>MORE SEARCH</span><span className="close_6722 ml-4" id="show" style={{ display: "none" }} onClick={hidepopup}>&times;</span>
                  </div>
                </section>
              </div>
            </div>
          </div>
        </div>
      </div>
      {
        popUp && (
          <div>
            <AboutFlightPopUp SetWaySelection={SetWaySelection} />

          </div>
        )
      }

      <div className="outerSec_20622">
        <div className="flightTicketdetails">
          <div className="row">
            <div className="col-md-3" style={{ marginTop: "43px" }}>
              <div className="filterList_19622">
                <details class="detailsComp_19622" open>
                  <summary class="summaryColapse_196222">
                    DEPARTURE TIMES
                  </summary>
                  <span style={{ padding: "8px", fontSize: "14px" }}> From Dasna</span>
                  <div>
                    <div className='lable_22622'>
                      <ul>
                        <li>
                          <p>0</p>
                          <span>5565</span>
                        </li>
                        <li>
                          <p>1</p>
                          <span>5565</span>
                        </li>
                        <li>
                          <p>1+</p>
                          <span>5565</span>
                        </li>
                      </ul>
                    </div>
                  </div>
                </details>
              </div>

              <div className="filterList_19622">
                <details class="detailsComp_19622" open>
                  <summary class="summaryColapse_196222">
                    DEPARTURE TIMES
                  </summary>
                  <span style={{ padding: "8px", fontSize: "14px" }}> From Dasna</span>
                  <div>
                    <div className='lable_19622'>
                      <ul>
                        <li>
                          <span><i class="fa-solid fa-sun"></i></span><br />
                          <p>05-10</p>
                        </li>
                        <li>
                          <span><i class="fa-solid fa-moon"></i></span><br />
                          <p>05-10</p>
                        </li>
                        <li>
                          <span><i class="fa-solid fa-sun"></i></span><br />
                          <p>05-10</p>
                        </li>
                        <li>
                          <span><i class="fa-solid fa-moon"></i></span><br />
                          <p>05-10</p>
                        </li>
                      </ul>
                    </div>
                  </div>
                </details>
              </div>

              <div className="filterList_19622">
                <details class="detailsComp_19622" open>
                  <summary class="summaryColapse_196222">
                    DEALS
                  </summary>
                  <div>
                    <div className='lable_19622'>
                      <input type="checkbox" className='inputs_19622' />
                      <label htmlFor="vehicle2"> Exclusive deals Only</label><br />
                    </div>
                  </div>
                </details>
              </div>

              <div className="filterList_19622">
                <details class="detailsComp_19622" open>
                  <summary class="summaryColapse_196222">
                    AIRLINES
                  </summary>
                  <div>
                    <div className='lable_19622'>
                      <input type="checkbox" className='inputs_19622' />
                      <label htmlFor="vehicle2"> Exclusive deals Only</label>
                      <span style={{ float: "right" }}>₹ 10150</span><br />
                      <input type="checkbox" className='inputs_19622' />
                      <label htmlFor="vehicle2"> Exclusive deals Only</label>
                      <span style={{ float: "right" }}>₹ 10150</span><br />
                      <input type="checkbox" className='inputs_19622' />
                      <label htmlFor="vehicle2"> Exclusive deals Only</label>
                      <span style={{ float: "right" }}>₹ 10150</span>
                    </div>
                  </div>
                </details>
              </div>

              <div className="filterList_19622">
                <details class="detailsComp_19622" open>
                  <summary class="summaryColapse_196222">
                    PRICE RANGE
                  </summary>
                  <div>
                    <div className='lable_19622'>
                      <input type="range" min={1} max={100} defaultValue={50} className="slider_20622" id="myRange" />
                    </div>
                  </div>
                </details>
              </div>
            </div>

            <div className="col-md-9">
              <div className="hideShow_22622">
                <ul>
                  <li className="btnSec_12622" id="defaultvalue" onClick={(event) => tabs2(event, "firstTab")}>
                    Fare Trends
                  </li>
                  <li className="btnSec_12622" onClick={(event) => tabs2(event, "secondTab")}>
                    Best Value
                  </li>
                </ul>
                <p style={{ float: "right", marginTop: "revert" }}>Showing 18 of 40 Flights found <span>(Show all)</span></p>
              </div>

              {/* === */}
              <div className="cardstyle_22622 tabSec_22622 mt-2" id="secondTab">
                <div className="row justify-tabtent-center text-center">
                  {
                    Array(6).fill().map((i) => (
                      <div className="col-md-2 col-4">
                        <div className="cardstyle11_22622" style={{ display: "flex", flexDirection: "row" }}>
                          <div style={{ width: "30%", display: "grid" }}>
                            <img src="https://dhiz4uvf5rpaq.cloudfront.net/in/V1/assets/images/AirlineLogo/6E.jpg" style={{ margin: "auto" }} />
                          </div>
                          <div style={{ width: "70%", display: "grid" }}>
                            <section className="flightDet_22622" style={{ margin: "auto", width: "100%", marginTop: "12px" }}>
                              <span>IndiGo</span>
                              <p>₹ 9132</p>
                            </section>
                          </div>
                        </div>
                      </div>
                    ))
                  }
                </div>
              </div>
              {/* ====== */}

              <div className="datePrice mt-2 tabSec_22622" id="firstTab">
                <SliderDate />
              </div>

              {/* card ==================================================================start */}


              {/* card ================================================================== end*/}
              {
                waySelection ? <FlightSec /> : <RoundTrip />
              }






            </div>
          </div>

        </div>
      </div>
    </>
  );
}

export default FlightDetails;
