import React from "react";
import "./AllDetailsBus.css";
function AllDetailsBus() {
  return (
    <>
      <div className="safety79 mt-3">
        <div className="wrapperSafety79">
          <img
            src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAABICAYAAABV7bNHAAAAAXNSR0IArs4c6QAAAERlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAAASKADAAQAAAABAAAASAAAAACQMUbvAAAG7ElEQVR4Ae2ca2wUVRTH/zttF1QoFKU0PtICaSABgoASYsQvQmmTlvJBDUGKH7Spjw/41k+iiTGEh0ZN/CCJhkCJNG2QQqBREIRIa3mska6gBiqllC2UpVv63EfrOQNTd7szO7OdO7uLnZNMpzP3zr3n/PbcO/feufc6hkigId0B4GAzUHsBONsBtHUDHX2A9hMaCRm8nd7tQXr3VYOxRxPNAUdaOpwZGciZPB4lcybh7aWZmHafpJmYQw1QXxD4/AywsRHwDWg+KzzAekAqKktpeHrONOx4LhtZ4x1REaIANd0ASr8HLnZGxbX8RlIA3bEqLWMcKl+YgdJZ4yPsjPCtHy4BT+xKDpwIrZJwEQoMYPU3f2HT8VsRuQ8DYs95pha45Y8IH1sXgyFs2N+MvX/2D9stA+I6h4vVmIajICFIz2+/iJv9t99dMiCukJNR5yg6pdqZi1tZ1TVZLYlf5fy2siWSwGF3O9p7BiFxOyeRr/JINVL4ioraluNdkPZSI9AWdQL73D5ITdRCtkWdgKezHxJ3H2xRJ+APBCBx3ypVRK2pn0zdhkJBSFZ1POMx7KmHgJqVwNV3snFi/SysWZiFjLToflE8aYqJOwQHtiQHkZNaYKtnA68vBBZMizbH0xXA1/Ud2EZHRw+1ZJMkCQWUNQ4omg6snHn7nEnXehIMDeGX5m7wG2U/HZduJrYvZCmgTCewiLzj8RygMA9Y+jCQPtz700OjHu729OHAHz78eqkHrtY+tJGnWSmmAXFV8eAE4JGJt4/cTGD+VOAxApOfBTgsrkq4KJ5p7YXrSi/+ueHH5U4/Wn0BtNJ5IKg5FmiYqSlADKFhDZBm0isMaxtnxA8OtGHzkfY4n4qMbso0Li6pCofNdKabd19TgCJZ/z+vbEA6v6sNyAakQ0An+K7yoFAopGOO+OC7BpDX68WSJUuwc+dO8RRipJgeIyxlghjOsmXL4HK5sG7dOlmvtWvXJkS/lPegcDhMhL+UM6TKykob0Eg4ChGGVFZWlhBIKetBWnDCIZWXl8Pj8Si3LDknFJDfb2yoQg8Ok3A6naiqqkJODg0VWCgJA9TQ0ID8/HycPHkypjlG4dTU1KC4uDhmWiICEwKI4axYsQItLS1Yvny5JqRUg8OALQdUX18vw+nq6pJ/UJ/PJ0NqbIz8nJuKcCwHxHAKCwuhwJEJ0R+GVFBQAAWSUTjV1dUJKVaKnpYC4ldxRUVFFBwlcwVSXV3dcCNQCRt55gqZ4ZSUlIwMsvzaVBEbjDGi6aCx1traWuTm5moawZCKiorkFrJWJDNwRHyvMQVoQKfvmJeXh6NHj8aEpAWG75uBw88PBAf5ZEpMAeo38LlqtJDMwmEqfYEYLm4Qm+WAWI94IYmAw/n2J9uD2nuNz5k2CkkUHAbUfsv8NzNzHkR1UGvkpFDWS1P0IImEw0pc6DDWtdFUmAJMAZKV8MVKPjpMC5JoONzMaPaanwVvGtCx1mgIendGQhINh/M/dblXyJdV04D2/K2HQz1cgcQdWCsagbVNcbq2upowPeT623Uq67RsYeZkjRxi3GZIbrcbGbS4RKRw8dpzVsxaCtMexIZtODF680TDYU0qT3upgjZf/3BaQgDtOgc0WrmKiTU1KL3+QWw4KE4ZIYC4vfrqYW7aG7TCwmgf1rUJnTMkBBDbe5pmmbxyyELLDSS92+XFl8epUhQowgCxTt+6gXd/FqhdHEkdPOdD+e6WOJ4wFlUoIM5y8yngzSNArKEQY6oZj7Xn906s3t6MAM1nFC3CAbGCn9HqoWdp7VmP+a6Qrr1baQbZmh3N8FsAhzM3NQVPT/vZU4Aq+vAwj+YsihZvbxAVVS3yzFfRaYenZ4kHKRmc9wKL6QvxVip2IfNjV0qyqKP6ZvGn5y2Hwxla6kHDFtE/POFzWwHwaHb43fj+5+GL9/ZdwW7XzfgeNBE7YYBYR3bXF+cBHz8JZN9rXGseOv3i2DVs+qkd3QMCXdGACgkFpOjDE8zfWERvOzpizbbnWfbcbfjkx6to6UxAja8oGHZOCiAl/ym0RP0tgvTaAmBS2LIEfl1/R42+jYc8uEiTw5MpDsdW6vuKbz7EZRN71MvzgZfmBHGgiVvD13CFZssnX2gri6lfDQ1dp7HlVJBk7rygZr8jLQMSr7OwRZ0Ab4IizX1APdC+C3mHGKmU1m7Zok6At8+ReIFb+BtEPeoYvEvb5vDeQtIEGg5+f/EYBKBjMu8pxBsvyX2x9bRudMYoBt118rhrg3kvId5wiUUGdA9929i7CphI7ZExL1S0eKMlZYn6cG9+7v1ANS3NHtOQCM5HxdMjdqGyt+i6U2S0tuiKAsTx7U3e/qtoVAEpwfY2gcC/dUzWUuXgehUAAAAASUVORK5CYII="
            alt=""
          />
          <span className="ml-2">
            <span>
              <b style={{ color: "blue" }}>My</b>Safety
            </span>
            <strong>- Important advisories & state guidelines</strong>
          </span>
          <p>
            With travel opening up, govt. advisories and state/UT guidelines are
            constantly evolving. Please check the latest updates before
            travelling.  <b style={{color:'blue',fontSize:'13px',float:'right'}}>KNOW MORE</b>
          </p>
          <ul style={{marginTop:'-15px'}}>
            <li><i class="fa fa-arrow-circle-right text-success" aria-hidden="true"></i> Staff with Masks</li>
            <li><i class="fa fa-arrow-circle-right text-success" aria-hidden="true"></i> Sanitized Buses</li>
            <li><i class="fa fa-arrow-circle-right text-success" aria-hidden="true"></i> Temperature Checks</li>
            <li><i class="fa fa-arrow-circle-right text-success" aria-hidden="true"></i> Hand Sanitizers</li>
            <li><i class="fa fa-arrow-circle-right text-success" aria-hidden="true"></i> No Linen / Blankets</li>
          </ul>
        </div>
      </div>
    </>
  );
}

export default AllDetailsBus;
