import React from 'react'
import AllDetailsBus from './AllDetailsBus'
import './Bus.css'
import SideDetails from './SideDetails'
import SliderRes from './SliderRes'
import Zingbus from './Zingbus'
function Bus() {
  return (
    <>
      <div className="busDestination77 sticky-top" >
        <div className="wrapperDestination77">
           <form action="">
           <div className="row">
              <div className="col-md-3 ">
                <div className="inputFromDelhi77">
                    <div className="form-group">
                <label htmlFor="inputEmail4" className='ml-2'>From</label>
                <input type="text" className="form-control" placeholder="Delhi" />
              </div>
                </div>
              </div>
              <div className="col-md-3 ">
              <div className="inputFromDelhi77">
                    <div className="form-group">
                <label htmlFor="inputEmail4" className='ml-2'>To</label>
                <input type="text" className="form-control" placeholder="Mumbai" />
              </div>
                </div>
              </div>
              <div className="col-md-3 ">
                <div className="departBus77 mb-2">
                <div className="inputFromDelhi771">  
                <p  className='ml-2'>Depart</p>
                <h6 className='text-white mt-3  ml-2'>Thu, 7 Jul 2022</h6>       
                </div>
                </div>
              </div>
              <div className="col-md-3 ">
                <div className="btnBus77">
                  <button className="btn77">Search</button>
                </div>
              </div>
            </div>
           </form>
        </div>
      </div>

      <div className="relevance87">
          <div className="wrapperRevelance87">
       {/* <ul className='navbar-nav'>
       <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
         Sorted by Revelance 
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="#">Action</a>
          <a class="dropdown-item" href="#">Another action</a>
        </div>
      </li>
       </ul> */}

<nav class="navbar sortdata_24622 navbar-expand-lg">
  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Shorted by Revelance
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="#">Action</a>
          <a class="dropdown-item" href="#">Another action</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="#">Something else here</a>
        </div>
      </li>
      <li class="nav-item itemBorder78">
        <a class="nav-link ml-3  " >Showing 37 out of 37 buses from Kanpur</a>
      </li>
    </ul>
  </div>
</nav>
       
          </div>
      </div>
      <div className="container">
      <div className="sideDetails97 mt-5">
            <div className="row">
              <div className="col-md-3 ">
                  <SideDetails/>
              </div>
              <div className="col-md-9">
                <SliderRes/>
                  <AllDetailsBus/>
                  <Zingbus/>
              </div>
            </div>
          </div>
          </div>
    </>
  )
}

export default Bus