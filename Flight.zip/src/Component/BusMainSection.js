import React from 'react'
import { BrowserRouter ,Routes , Route } from 'react-router-dom'
// import Hotel from './Hotel'
// import Navbar from './Navbar'
import Bus from './Bus'



function Main() {
  return (
    <div>
        <BrowserRouter>
        {/* <Navbar/> */}
        <Routes>
        <Route path="/"  element={<Bus />} />
        {/* <Route path="/hotel"  element={<Hotel />} /> */}
        </Routes>
        </BrowserRouter>
    </div>
  )
}

export default Main;