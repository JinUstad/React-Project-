import React from 'react'
import { Link } from 'react-router-dom'
import './CardIcon.css'
function CardIcon() {
    
    
  return (
    <>
            <div className="ticketBooking">
                  <div className="wrapperTicketBooking">
                      <i className='fa fa-plane'></i>
                  <p ><Link to="/flight" >Flight</Link></p>
                  </div>
                  <div className="wrapperTicketBooking">
                      <i className='fa fa-hotel'></i>
                  <p><Link to="/hotels">Hotel</Link></p>
                  </div>
                  <div className="wrapperTicketBooking">
                  <i className="fa-solid fa-tree"></i>
                  <p><Link to="/holiday">Holidays</Link></p>

                  </div>
                  <div className="wrapperTicketBooking">
                      <i className='fa fa-bus'></i>
                  <p><Link to="/busDetails">Bus</Link></p>
                  </div>
                  <div className="wrapperTicketBooking">
                      <i className='fa fa-passport'></i>
                      <p>Visa</p>
                  </div>
                  <div className="wrapperTicketBooking">
                      <i className='fa fa-passport'></i>
                      <p>Visa</p>
                  </div>
            </div>

            
    </>
  )
}

export default CardIcon