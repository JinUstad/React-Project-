import React , {useState} from 'react'
import './Demo.css'

function Demo() {

    const [menu , SetMenuToogle] = useState(false)
    const [seatmenu , SetseatMenuToogle] = useState(false)
    function showData() {
        // document.getElementById("hide").style.width = "900px"
        SetMenuToogle(true)
        
    }
    function show() {
        // document.getElementById("hidedata").style.width = "900px"
        SetseatMenuToogle(true)
    }
  
    function hideData() {
        SetMenuToogle(false)
        SetseatMenuToogle(false)
        document.getElementById("hide").style.width = "0px"
        document.getElementById("hidedata").style.width = "0px"
    }

    function submitData(e) {
        e.preventDefault();


    }
    return (
        <>
            <div >
                <div className="container mt-4">
                    <div className="row">
                        <div className="col-md-9">
                            <h5 style={{ fontSize: "14px" }}>Review your flight details <a href="" style={{ float: "right" }}>Back to Search</a></h5>

                            <div className="overview206" style={{ backgroundColor: "white", padding: "20px" }}>
                                <div className="row mb-3" style={{ backgroundColor: "#f4f4f6" }}>
                                    <div className="col-md-4 ">
                                        <div className="cardstyle11_22622" style={{ display: "flex", flexDirection: "row" }}>
                                            <div style={{ width: "10%", marginRight:"2px", display: "grid" }}>
                                                <img src="https://dhiz4uvf5rpaq.cloudfront.net/in/V1/assets/images/AirlineLogo/6E.jpg" style={{ margin: "auto" }} />
                                            </div>
                                            <div style={{ width: "70%", display: "grid" }}>
                                                <section className="flightDet_22622" style={{ marginBottom: "-10px", width: "100%", marginTop: "2px" }}>
                                                    <span>IndiGo</span>
                                                    <p>₹ 9132</p>
                                                </section>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="col-md-2 col-6 mt-auto" >
                                        <div className='flightList_23622'>
                                            <span>Aircraft</span><br />
                                            <p>Aircraft</p>
                                        </div>
                                    </div>
                                    <div className="col-md-2 col-6 mt-auto">
                                        <div className='flightList_23622  '>
                                            <span>Travel Class</span><br />
                                            <p>Economy</p>
                                        </div>
                                    </div>
                                    <div className="col-md-2 col-6  mt-auto">
                                        <div className='flightList_23622 '>
                                            <span>Check-In Baggage</span><br />
                                            <p>Adult-15 Kg</p>
                                        </div>
                                    </div>
                                    <div className="col-md-2 col-6 mt-auto">
                                        <div className='flightList_23622 '>
                                            <span>Cabin Baggage</span><br />
                                            <p>Adult-7 Kg</p>
                                        </div>
                                    </div>
                                </div>
                                <div className="row">
                                    <div className="flightDetails_23622">

                                    </div>
                                    <div className="col-md-4 col-4">
                                        <div className="Timing_20622">
                                            <h5>13:15</h5>
                                            <h6>Tue, 21 Jun 22</h6>
                                            <span>Kolkata [CCU]</span>
                                            <span>Netaji Subhas Chandra |Kolkata |IN |India</span>
                                        </div>
                                    </div>
                                    <div className="col-md-4 col-4">
                                        <li className=" float_18622  hff465768790" style={{ marginTop: "auto", listStyle: "none" }}>
                                            <div className="lineDistance_20622"></div>
                                            <i className="fa-solid fa-plane  plan_2622"></i>

                                        </li>
                                    </div>
                                    <div className="col-md-4 col-4">
                                        <div className="Timing_20622">
                                            <h5>13:15</h5>
                                            <h6>Tue, 21 Jun 22</h6>
                                            <span>Kolkata [CCU]</span>
                                            <span>Netaji Subhas Chandra |Kolkata |IN |India</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="Log_inFlight mt-4">

                                <div className="row">
                                    <div className="col-md-6 col-12 mb-2 accountFlight">
                                        {/* <ul> */}
                                            <li>
                                                <i className="fa fa-lock-open mr-3"></i>Log-in to your
                                                Akbartravels account
                                            </li>
                                        {/* </ul> */}
                                    </div>
                                    <div className="col-md-6 col-12">
                                        <div style={{float:"right"}}>
                                            <span className='logGuest'>Log-in</span>
                                            <button className="btn btn-danger text-white">
                                                Continue as Guest
                                            </button>
                                        </div>
                                    </div>
                                </div>
                                {/* <div className="accountFlight">
                                    <ul>
                                        <li>
                                            <i className="fa fa-lock-open mr-3"></i>Log-in to your
                                            Akbartravels account
                                        </li>
                                        <li className="logGuest ml-4">
                                            <button className="btn btn-danger text-white">
                                                Continue as Guest
                                            </button>
                                        </li>
                                        <li className="logGuest">Log-in</li>
                                    </ul>
                                </div> */}
                            </div>
                            <div className="mt-4">
                                <h5>Make your booking refundable</h5>
                            </div>
                            {/* Covid-19 Infection & Isolation */}
                            <div className="infectionIsolation">
                                <div className="flightIsolation">
                                    <div className="COVID_19">
                                        <p>
                                            <i class="fa-solid fa-weight-hanging mr-2"></i> COVID-19
                                            Infection & Isolation{" "}
                                        </p>
                                        <h6>
                                            <i className="fa fa-plane mr-2"></i> 63% of our flyers
                                            upgrade to a Refundable booking.
                                        </h6>
                                    </div>
                                    <hr />
                                </div>
                                <div className="sicknessFlight">
                                    <div className="row">
                                        {
                                            Array(8).fill().map((e) => (
                                                <div className="col-md-4">
                                                    <div className="Sickness">
                                                        <p><i class="fa fa-check-circle"></i> Sickness / Accident / Injury</p>
                                                    </div>
                                                </div>
                                            ))
                                        }
                                    </div>
                                </div>
                                <hr />
                                <div className="termsConditions">
                                    <p>Upgrade your Booking and receive upto 100% if you cannot attend and can evidence one of the many reasons in our <u>Terms and Conditions</u> , which you accept when you select a Refundable Booking.</p>
                                    <div>

                                        <div className="row ">
                                            <div className="col-md-8">
                                                <input type="radio" id="html" name="fav_language" defaultValue="HTML" />&nbsp;
                                             <label className="labelText" htmlFor="html">Yes make my booking refundable (recommended) </label><br />
                                                
                                               
                                             <input type="radio" id="css" name="fav_language" defaultValue="CSS" />&nbsp;
                                             <label className="labelText" htmlFor="css">No do not make my booking Refundable and accept terms might be Non-Refundable</label>
                                              
                                            </div>
                                            <div className="col-md-4 my-1">
                                                <span className="amount"><b>Premium Amount</b></span> <br />
                                                <span className="rupye "><b>₹ 861</b></span>
                                            </div>
                                        </div>
                                    
                                    </div>
                                </div>
                            </div>
                            {/* Traveller Details */}
                            <div className="travellerDetailsFlight mt-4">
                                <div className="mt-2">
                                    <h5>Traveller Details</h5>

                                </div>

                                <div className="detailFlight23">
                                    <p><i class='fa fa-warning'></i> Please make sure you enter the Name as per your Government photo id.</p>
                                    <div className="inputFlight">
                                        <details open>
                                            <summary style={{ border: "1px solid #cfc6c6", padding: "6px", backgroundColor: "#f4f4f6", color: "#c3584b" }}>Adult × 1</summary>
                                            <hr />
                                            <span> <select className="selectGen_23622">
                                                <option>Mr</option>
                                                <option>Ms</option>
                                                <option>Mrs</option>
                                            </select></span>

                                            <span className='inputfield_23622'><input type="text" placeholder='First Name' name="" id="" /></span>   &nbsp; <span className='inputfield_23622'><input type="text" placeholder='Last Name' name="" id="" /></span>
                                        </details>
                                    </div>
                                </div>
                            </div>
                            {/* ============================ */}
                            <div className='mt-4'>
                                <h5>Contact information</h5>
                                <div className='contactDetail_23622'>
                                    <span style={{ display: "flex" }}><i class="fa-solid fa-address-card"></i> <span style={{ marginLeft: "15px" }}><p>Your ticket and flights information will be sent here.</p></span> </span>
                                    <hr />
                                    <span><input type="text" placeholder='Mobile Number' name="" id="" /></span>   &nbsp; <span><input type="email" placeholder='Enter Email' name="" id="" /></span>
                                </div>
                            </div>
                            {/* ============= */}
                            <div className='services_23622 mt-2'>
                                <details>
                                    <summary style={{ paddingTop: "10px" }}><span style={{ display: "flex", marginLeft: "35px", marginTop: "-25px" }}><i class="fa-solid fa-address-card"></i> <span style={{ marginLeft: "15px" }}><p><b>Use GSTIN for this booking</b> (Optional)</p></span> </span></summary>

                                    <hr />
                                    <span className='inputfield_23622'><input type="text" placeholder='First Name' name="" id="" /></span>   &nbsp; <span className='inputfield_23622'><input type="text" placeholder='Last Name' name="" id="" /></span>
                                </details>
                            </div>
                            {/* =================================== */}
                            <div className="addonServices623 mt-4" style={{ boxShadow: "none" }}>
                                <h5>Addon Services</h5>
                                <div className="Services623">
                                    <div className="suitcase_23622">
                                        <button className="btn " onClick={showData}>
                                            <i class="fa fa-suitcase mr-2"></i>Add Baggage
                                        </button>
                                        <button className="btn " onClick={show}>
                                            <i class="fa-solid fa-chair mr-2"></i>Seat Section
                                        </button>
                                    </div>
                                </div>
                            </div>
                            {/* sidebar  ======================================= */}
                            <div className="formPopUp_23622 " id='hide' style={menu ?{width:"100%"}:  { width: "0px" }}>
                                <form onSubmit={submitData} className="formContainer_23622">
                                    <span>Select Baggage</span><span className='closeButton' onClick={hideData}> <i className='fa fa-close'></i></span>
                                    <hr />
                                    <h6>ONWARD</h6>
                                    <div className='mainSecCard_23622'>
                                        <div className='rowData_23622'>
                                            <hr />
                                            <div className='flexSec_23622'>
                                                Traveller
                                            </div>
                                            <div className='flexSec_23622'>
                                                Ahmedabad &rarr; Kolkata
                                            </div>
                                            <hr />
                                        </div>
                                        <div className='rowData_23622' style={{ fontSize: "14px" }}>
                                            <hr />
                                            <div className='flexSec_23622'>
                                                Adult 1
                                            </div>
                                            <div className='flexSec_23622' style={{ color: "red" }}>
                                                - Add Your Baggage
                                            </div>
                                            <hr />
                                        </div>
                                        {/*  ===*/}
                                        <div className="card mt-2" style={{ width: '18rem' }}>
                                            <img src="https://c0.wallpaperflare.com/preview/205/41/252/three-assorted-apple-products.jpg" className="card-img-top" alt="..." style={{ height: "150px" }} />
                                            <div className="card_body_23622 text-center">
                                                <p>Prepaid Excess Baggage – 3 Kg</p>
                                                <div className='btnbtn_23622 text-center'>
                                                    <button>ADD</button>
                                                </div>
                                            </div>
                                        </div>
                                        <hr />
                                    </div>

                                    <h5>Other Addon Services</h5>
                                    <hr />
                                    <div className="Services623">
                                        <div className="suitcase_23622">
                                            <button className="btn ">
                                                <i class="fa-solid fa-chair mr-2"></i>Seat Section
                                            </button>
                                        </div>
                                    </div>

                                    {/* ==== */}
                                    <div className="amountSec_22622" style={{ display: "flex", flexDirection: "row", width: "97.5%" }}>
                                        <div className='amountHed' style={{ width: "20%", display: "grid" }}>
                                            <h5>Total Amount
                                                for Select Baggage</h5>
                                        </div>
                                        <div className='amout_22622' style={{ width: "55%", display: "grid" }}>
                                            <section style={{ marginTop: "auto" }}>
                                                <p>₹ 9132</p>
                                            </section>
                                        </div>
                                        <div className='btnbtnSec_22622' style={{ width: "12%", display: "grid", marginLeft: "88px" }}>
                                            <button>Done</button>
                                        </div>
                                    </div>
                                    {/* ==== */}




                                </form>
                            </div>
                            {/*  sidebar======================================= */}







                            {/* wahid======================================================== */}
                            <div className="formPopUp_23622" id='hidedata' style={seatmenu ? { width: "100%" } : { width: "0px" }}>
                                <form onSubmit={submitData} className="formContainer_23622">
                                    <span>Select Baggage</span><span className='closeButton' onClick={hideData}> <i className='fa fa-close'></i></span>
                                    <hr />
                                    <h6>ONWARD</h6>
                                    <div className='mainSecCard_23622'>
                                        <div className='rowData_23622'>
                                            <hr />
                                            <div className='flexSec_23622'>
                                                Traveller
                                            </div>
                                            <div className='flexSec_23622'>
                                                Ahmedabad &rarr; Kolkata
                                            </div>
                                            <hr />
                                        </div>
                                        <div className='rowData_23622' style={{ fontSize: "14px" }}>
                                            <hr />
                                            <div className='flexSec_23622'>
                                                Adult 1
                                            </div>
                                            <div className='flexSec_23622' style={{ color: "red" }}>
                                                - Add Your Baggage
                                            </div>
                                            <hr />
                                        </div>
                                        {/* seat========================================= */}
                                        <div>

                                            <div className="row my-4">
                                                <div className="col-md-6">
                                                    <div className="seatsChart">
                                                        <div className="seatRow">
                                                            <div className="seatRowNumber">
                                                                Row 1
                                                            </div>
                                                            <div id="1_1" title role="checkbox" value={45} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber seatUnavailable">1</div>
                                                            <div id="1_2" role="checkbox" value={45} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber ">2</div>
                                                            <div id="1_3" role="checkbox" value={45} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber ">3</div>
                                                            <div id="1_4" role="checkbox" value={45} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber seatUnavailable">4</div>
                                                            <div id="1_5" role="checkbox" value={45} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber ">5</div>
                                                            <div id="1_6" role="checkbox" value={45} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber  ">6</div>
                                                            <div id="1_7" role="checkbox" value={45} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber ">7</div>
                                                            <div id="1_8" role="checkbox" value={45} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber ">8</div>
                                                        </div>
                                                        <div className="seatRow">
                                                            <div className="seatRowNumber">
                                                                Row 2
                                                            </div>
                                                            <div id="2_1" role="checkbox" value={42} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber ">1</div>
                                                            <div id="2_2" role="checkbox" value={42} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber seatUnavailable">2</div>
                                                            <div id="2_3" role="checkbox" value={42} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber ">3</div>
                                                            <div id="2_4" role="checkbox" value={42} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber ">4</div>
                                                            <div id="2_5" role="checkbox" value={42} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber ">5</div>
                                                            <div id="2_6" role="checkbox" value={42} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber  ">6</div>
                                                            <div id="2_7" role="checkbox" value={42} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber ">7</div>
                                                            <div id="2_8" role="checkbox" value={42} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber seatUnavailable">8</div>
                                                        </div>
                                                        <div className="seatRow">
                                                            <div className="seatRowNumber">
                                                                Row 3
                                                            </div>
                                                            <div id="3_1" role="checkbox" value={38} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber seatUnavailable">1</div>
                                                            <div id="3_2" role="checkbox" value={38} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber ">2</div>
                                                            <div id="3_3" role="checkbox" value={38} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber seatUnavailable">3</div>
                                                            <div id="3_4" role="checkbox" value={38} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber ">4</div>
                                                            <div id="3_5" role="checkbox" value={38} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber seatUnavailable">5</div>
                                                            <div id="3_6" role="checkbox" value={38} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber  ">6</div>
                                                            <div id="3_7" role="checkbox" value={38} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber ">7</div>
                                                            <div id="3_8" role="checkbox" value={38} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber ">8</div>
                                                        </div>
                                                        <div className="seatRow">
                                                            <div className="seatRowNumber">
                                                                Row 4
                                                            </div>
                                                            <div id="4_1" role="checkbox" value={30} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber ">1</div>
                                                            <div id="4_2" role="checkbox" value={30} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber ">2</div>
                                                            <div id="4_3" role="checkbox" value={30} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber ">3</div>
                                                            <div id="4_4" role="checkbox" value={30} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber ">4</div>
                                                            <div id="4_5" role="checkbox" value={30} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber ">5</div>
                                                            <div id="4_6" role="checkbox" value={30} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber seatUnavailable ">6</div>
                                                            <div id="4_7" role="checkbox" value={30} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber ">7</div>
                                                            <div id="4_8" role="checkbox" value={30} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber ">8</div>
                                                        </div>
                                                        <div className="seatRow">
                                                            <div className="seatRowNumber">
                                                                Row 5
                                                            </div>
                                                            <div id="5_1" role="checkbox" value={28} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber seatUnavailable">1</div>
                                                            <div id="5_2" role="checkbox" value={28} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber ">2</div>
                                                            <div id="5_3" role="checkbox" value={28} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber ">3</div>
                                                            <div id="5_4" role="checkbox" value={28} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber seatUnavailable">4</div>
                                                            <div id="5_5" role="checkbox" value={28} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber ">5</div>
                                                            <div id="5_6" role="checkbox" value={28} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber seatUnavailable ">6</div>
                                                            <div id="5_7" role="checkbox" value={28} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber ">7</div>
                                                            <div id="5_8" role="checkbox" value={28} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber ">8</div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className="col-md-6">
                                                    <div className="seatsChart mobseatsChart ">
                                                        <div className="seatRow">
                                                            <div className="seatRowNumber">
                                                                Row 1
                                                            </div>
                                                            <div id="1_1" title role="checkbox" value={45} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber seatUnavailable">1</div>
                                                            <div id="1_2" role="checkbox" value={45} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber ">2</div>
                                                            <div id="1_3" role="checkbox" value={45} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber ">3</div>
                                                            <div id="1_4" role="checkbox" value={45} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber seatUnavailable">4</div>
                                                            <div id="1_5" role="checkbox" value={45} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber ">5</div>
                                                            <div id="1_6" role="checkbox" value={45} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber  ">6</div>
                                                            <div id="1_7" role="checkbox" value={45} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber ">7</div>
                                                            <div id="1_8" role="checkbox" value={45} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber ">8</div>
                                                        </div>
                                                        <div className="seatRow">
                                                            <div className="seatRowNumber">
                                                                Row 2
                                                            </div>
                                                            <div id="2_1" role="checkbox" value={42} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber ">1</div>
                                                            <div id="2_2" role="checkbox" value={42} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber seatUnavailable">2</div>
                                                            <div id="2_3" role="checkbox" value={42} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber ">3</div>
                                                            <div id="2_4" role="checkbox" value={42} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber ">4</div>
                                                            <div id="2_5" role="checkbox" value={42} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber ">5</div>
                                                            <div id="2_6" role="checkbox" value={42} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber  ">6</div>
                                                            <div id="2_7" role="checkbox" value={42} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber ">7</div>
                                                            <div id="2_8" role="checkbox" value={42} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber seatUnavailable">8</div>
                                                        </div>
                                                        <div className="seatRow">
                                                            <div className="seatRowNumber">
                                                                Row 3
                                                            </div>
                                                            <div id="3_1" role="checkbox" value={38} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber seatUnavailable">1</div>
                                                            <div id="3_2" role="checkbox" value={38} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber ">2</div>
                                                            <div id="3_3" role="checkbox" value={38} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber seatUnavailable">3</div>
                                                            <div id="3_4" role="checkbox" value={38} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber ">4</div>
                                                            <div id="3_5" role="checkbox" value={38} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber seatUnavailable">5</div>
                                                            <div id="3_6" role="checkbox" value={38} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber  ">6</div>
                                                            <div id="3_7" role="checkbox" value={38} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber ">7</div>
                                                            <div id="3_8" role="checkbox" value={38} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber ">8</div>
                                                        </div>
                                                        <div className="seatRow">
                                                            <div className="seatRowNumber">
                                                                Row 4
                                                            </div>
                                                            <div id="4_1" role="checkbox" value={30} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber ">1</div>
                                                            <div id="4_2" role="checkbox" value={30} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber ">2</div>
                                                            <div id="4_3" role="checkbox" value={30} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber ">3</div>
                                                            <div id="4_4" role="checkbox" value={30} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber ">4</div>
                                                            <div id="4_5" role="checkbox" value={30} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber ">5</div>
                                                            <div id="4_6" role="checkbox" value={30} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber seatUnavailable ">6</div>
                                                            <div id="4_7" role="checkbox" value={30} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber ">7</div>
                                                            <div id="4_8" role="checkbox" value={30} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber ">8</div>
                                                        </div>
                                                        <div className="seatRow">
                                                            <div className="seatRowNumber">
                                                                Row 5
                                                            </div>
                                                            <div id="5_1" role="checkbox" value={28} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber seatUnavailable">1</div>
                                                            <div id="5_2" role="checkbox" value={28} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber ">2</div>
                                                            <div id="5_3" role="checkbox" value={28} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber ">3</div>
                                                            <div id="5_4" role="checkbox" value={28} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber seatUnavailable">4</div>
                                                            <div id="5_5" role="checkbox" value={28} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber ">5</div>
                                                            <div id="5_6" role="checkbox" value={28} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber seatUnavailable ">6</div>
                                                            <div id="5_7" role="checkbox" value={28} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber ">7</div>
                                                            <div id="5_8" role="checkbox" value={28} aria-checked="false" focusable="true" tabIndex={-1} className=" seatNumber ">8</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                           
                                            {/* <div className="checkout col-lg-offset-6">
                                                <span>Subtotal: CA$</span><span className="txtSubTotal">0.00</span><br /><button id="btnCheckout" name="btnCheckout" className="btn btn-primary"> Check out </button>
                                            </div> */}
                                        </div>

                                        {/* seat========================================= */}
                                        <hr />
                                    </div>

                                    <h5>Other Addon Services</h5>
                                    <hr />
                                    <div className="Services623" style={{ boxShadow: "none" }}>
                                        <div className="suitcase_23622">
                                            <button className="btn ">
                                                <i class="fa-solid fa-chair mr-2"></i>Seat Section
                                            </button>
                                        </div>
                                    </div>

                                    {/* ==== */}
                                    <div className="amountSec_22622" style={{ display: "flex", flexDirection: "row", width: "97.5%" }}>
                                        <div className='amountHed' style={{ width: "20%", display: "grid" }}>
                                            <h5>Total Amount
                                                for Select Baggage</h5>
                                        </div>
                                        <div className='amout_22622' style={{ width: "55%", display: "grid" }}>
                                            <section style={{ marginTop: "auto" }}>
                                                <p>₹ 9132</p>
                                            </section>
                                        </div>
                                        <div className='btnbtnSec_22622' style={{ width: "12%", display: "grid", marginLeft: "88px" }}>
                                            <button>Done</button>
                                        </div>
                                    </div>
                                    {/* ==== */}
                                </form>
                            </div>
                            {/* wahid========================================================= */}

                        </div>

                        <div className="col-md-3">
                            <h5 style={{ fontSize: "14px" }}>Summery Detail</h5>
                            <div className='PromoCode'>
                                <div>
                                    <details classname="details_comp20622" style={{ padding: "6px", borderBottom: "1px solid #ebebeb" }}>
                                        <hr />
                                        <summary classname="summary_colapse20622 " style={{ fontSize: "14px", fontWeight: "500", color: "gray" }}>
                                            Base Fare     <span style={{ float: "right" }}>₹ 345678</span>
                                        </summary>
                                        <p style={{ fontSize: "13px", marginBottom: "0px", color: "darkred" }}>   Adult (1 X ₹ 7254)    <span style={{ float: "right" }}>₹ 345678</span></p>
                                    </details>

                                    <details classname="details_comp20622" style={{ padding: "6px", borderBottom: "1px solid #ebebeb" }}>
                                        <hr />
                                        <summary classname="summary_colapse20622 " style={{ fontSize: "14px", fontWeight: "500", color: "gray" }} >
                                            Tax And Charges     <span style={{ float: "right" }}>₹ 4987</span>
                                        </summary>
                                        <p style={{ fontSize: "13px", marginBottom: "0px", color: "darkred" }}>   Adult (1 X ₹ 7254)    <span style={{ float: "right" }}>₹ 345678</span></p>
                                    </details>
                                    <p className='totalAmpount_23622'>  Total <span style={{ float: "right" }}>₹ 4987</span></p>
                                </div>
                            </div>


                            {/* ===== */}

                            <div className='promobottom_23622 mt-3'>
                                <h5>Promo Code</h5>
                                <div className='aboutPromocode_23622'>
                                    <span>Apply Promocode</span>
                                    <div className='promocodeSec_23622'>
                                        <input type="text" placeholder='Enter Promocode' /><button style={{ color: "red", float: "right", fontWeight: "500" }}>apply</button>
                                    </div>
                                </div>
                            </div>
                            {/* ======= */}

                            <p style={{ textAlign: "center", margin: "0", padding: "0px" }}>OR</p>

                            <div className='welcomeSec_23622'>
                                <p>Choose from the offers below</p>
                                {
                                    Array(20).fill().map((i) => (
                                        <div className='welcome_23622'>
                                            <input type="radio" id="name" name='welcome' /><span>WELCOME</span>
                                            <p>Get an instant cashback in your AT wallet of <b style={{ color: "black" }}>₹ 200</b></p>
                                        </div>
                                    ))
                                }
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default Demo