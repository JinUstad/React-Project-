import React,{useEffect} from "react";
import { useNavigate } from "react-router-dom";
import ImageSlider from "./ImageSlider";
import Imgslider1 from "./ImageSlider1";
import ImageSlider2 from "./ImageSlider2";
import ImageSlider3 from "./ImageSlider3";
import ImageSlider4 from "./ImageSlider4";
import './ExclusiveDeals.css'

function ExclusiveDeals() {
  const navigate = useNavigate()

  const viewAll = (e) => {
    navigate(`/view${e}`)
  }

  useEffect(() => {
    document.getElementById("bydefault").click()
  }, [])

  function tabfunction(event, tabname) {
    var btn, tab;
    tab = document.getElementsByClassName("tabSection");
    btn = document.getElementsByClassName("linkList_15622");

    for (var i = 0; i < tab.length; i++) {
      tab[i].style.display = "none";
    }

    for (var j = 0; j < btn.length; j++) {
      btn[j].className = btn[j].className.replace(" active", "");
    }
    document.getElementById(tabname).style.display = "block";
    event.currentTarget.classList += " active";
  }
  
 
  return (
    <div>
      <div className="exclusiveDeal mt-5">
        <div className="container">
        <span className="exclusive ">
          Exclusive <b>Deals</b>
          </span>  <div className="viewDetails float-right" onClick={() => viewAll('-offer')}><u>View All</u></div>
          <section class='FlexCon_7722'>
            <div className="linkList_15622 " id="bydefault" onClick={(event) => tabfunction(event, "firsttab")}>Hot Deal</div>
            <div className="linkList_15622" onClick={(event) => tabfunction(event, "secondtab")}>Flight</div>
            <div className="linkList_15622" onClick={(event) => tabfunction(event, "thirdtab")}>Hotel</div>
            <div className="linkList_15622" onClick={(event) => tabfunction(event, "fourttab")} >Holiday</div>
            <div className="linkList_15622" onClick={(event) => tabfunction(event, "fifthtab")} >Curise</div>
            {/* <div className="viewDetails" onClick={() => viewAll('-offer')}>View All</div> */}
          </section>
          {/* <div className="exclusiveList">
            <ul>
              <span className="exclusive ">
                Exclusive <b>Deals</b>{" "}
              </span>
              <li className="linkList_15622 ml-5" id="bydefault" onClick={(event) => tabfunction(event, "firsttab")}>Hot Deal</li>
              <li className="linkList_15622"  onClick={(event) => tabfunction(event, "secondtab")}>Flight</li>
              <li className="linkList_15622" onClick={(event) => tabfunction(event, "thirdtab")}>Hotel</li>
              <li className="linkList_15622" onClick={(event)=> tabfunction(event , "fourttab")}>Holiday</li>
              <li className="linkList_15622" onClick={(event)=> tabfunction(event , "fifthtab")}>Curise</li>
              <li className="viewDetails" onClick={() => viewAll('-offer')}>View All</li>
            </ul>
            </div> */}
          <div className="tabSection"  id="firsttab">
            <ImageSlider />
          </div>
          
          <div className="tabSection"  id="secondtab">
            <Imgslider1 />
          </div>

          <div className="tabSection"  id="thirdtab">
            <ImageSlider2 />
          </div>

          <div className="tabSection " id="fourttab">
            <ImageSlider3 />
          </div>

          <div className="tabSection"  id="fifthtab">
            <ImageSlider4 />
          </div>

          </div>

       
        </div>
    </div>
  );
}

export default ExclusiveDeals;
