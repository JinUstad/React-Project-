import React, { useState } from 'react'
import './SearchBar.css'
// import CardIcon from './CardIcon'
import './CardIcon.css'
import SearchBarDate from './SearchBarDate'
import Main from './Main'

function FlightBookingHeader() {
    const [adults, SetAdults] = useState(1);
    const [kids, SetKids] = useState(0);
    const [infent, SetInfents] = useState(0);
    const [memberSelectionBool, SetmemberSelection] = useState(false)


    function adultInc() {
        if (adults < 12) {
            SetAdults(adults + 1);
        } else {
        }
    }
    function adultDec() {
        if (adults >= 2) {
            SetAdults(adults - 1);
        } else {
        }
    }
    function kidsInc() {
        if (kids < 12) {
            SetKids(kids + 1);
        } else {
        }
    }
    function kidsDec() {
        if (kids >= 1) {
            SetKids(kids - 1);
        } else {
        }
    }
    function InfentInc() {
        if (infent < 12) {
            SetInfents(infent + 1);
        } else {
        }
    }
    function infentDec() {
        if (infent >= 1) {
            SetInfents(infent - 1);
        } else {
        }
    }

    function hide() {
        document.getElementById("hideclose").style.display="none"
    }

    function showadult() {
        SetmemberSelection(!memberSelectionBool)
    }
    return (
        <>
            <div className="mainSection_7622" style={{ position: "relative" }} id='hideclose'>
                    <div onClick={hide}  style={{position:"absolute", right:"10px", top:"10px", color:"white", fontSize:"25px", backgroundColor:"white", color:"black", padding:"0px 5px 0px 5px", borderRadius:"6px", cursor:"pointer"}}>&times;</div>
                <div className="container "  >
                    {/* <h2 className='text-center text-white'>Book Domestic and International Hotels</h2> */}
                    <hr style={{ color: "white" }} />
                    <div className="row chfhjfh">
                        <div className="col-md-3 colpadding_7622">
                            <div className="first_7622">
                                <div className="row">
                                    <div className="col-md-2">
                                        <div className="icon_7622" style={{ marginLeft: "25px" }}>
                                            <i class="fa-solid fa-location-dot"></i>
                                        </div>
                                    </div>
                                    <div className="col-md-10">
                                        <div className="input2_7622">
                                            <input type="text" placeholder='Location' className='form-control' />
                                            <span>Where Are You Going?</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="col-md-3 colpadding_7622">
                            <div className="first_7622">
                                <div className="row">
                                    <div className="col-md-2">
                                        <div className="icon_7622">
                                            <i class="fa-solid fa-calendar"></i>
                                        </div>
                                    </div>
                                    <div className="col-md-10">
                                        <div className="input_7622">
                                            <SearchBarDate />
                                            <span>Add Date/  <b style={{ color: "#ce1e1e" }}>Check In</b></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="col-md-3 colpadding_7622" >
                            <div className="first_7622">
                                <div className="row">
                                    <div className="col-md-2">
                                        <div className="icon_7622">
                                            <i class="fa-solid fa-calendar"></i>
                                        </div>
                                    </div>
                                    <div className="col-md-10">
                                        <div className="input_7622">
                                            <SearchBarDate />
                                            <span>Add Date/  <b style={{ color: "#ce1e1e" }}>Check Out</b></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div className="col-md-2 colpadding_7622">
                            <div className="first_7622">
                                <div className="row">
                                    <div className="col-md-2">
                                        <div className="icon_7622">
                                            <i class="fa-solid fa-users-line"></i>
                                        </div>
                                    </div>
                                    <div className="col-md-10">
                                        <div className="input_7622" onClick={showadult}>
                                            <p>Guests</p>
                                            <span className='guests_7622'>Add Guests</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            {
                                memberSelectionBool ? (
                                    <div className='gestSelection py-2 px-3' id="urstSelection">
                                        <div className="row ">
                                            <div className="col-6">
                                                <div style={{ fontSize: "14.5px", fontWeight: "500" }}>Adults</div>
                                                <div style={{ fontSize: "13px" }} className="text-secondary">Ages 13 or above</div>
                                            </div>
                                            <div className="col-6">
                                                <div style={{ display: "flex", flexDirection: 'row' }}>
                                                    <button className='selectionbtn' type="button" onClick={adultDec} style={{ width: '30%' }}>
                                                        <i className="fa fa-minus-circle" aria-hidden="true"></i>
                                                    </button>
                                                    <div className="" style={{ width: "40%", textAlign: "center" }}>{adults}</div>
                                                    <button className='selectionbtn' type="button" onClick={adultInc} style={{ width: '30%' }}>
                                                        <i className="fa fa-plus-circle" aria-hidden="true"></i>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                        <hr />
                                        <div className="row ">
                                            <div className="col-6">
                                                <div style={{ fontSize: "14.5px", fontWeight: "500" }}>Children</div>
                                                <div style={{ fontSize: "13px" }} className="text-secondary">Ages 2 to 12</div>
                                            </div>
                                            <div className="col-6">
                                                <div style={{ display: "flex", flexDirection: 'row' }}>
                                                    <button className='selectionbtn' type="button" onClick={kidsDec} style={{ width: '30%' }}>
                                                        <i className="fa fa-minus-circle" aria-hidden="true"></i>
                                                    </button>
                                                    <div className="" style={{ width: "40%", textAlign: "center" }}>{kids}</div>
                                                    <button type="button" className='selectionbtn' onClick={kidsInc} style={{ width: '30%' }}>
                                                        <i className="fa fa-plus-circle" aria-hidden="true"></i>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                        <hr />

                                        <div className="row ">
                                            <div className="col-6">
                                                <div style={{ fontSize: "14.5px", fontWeight: "500" }}>Infents</div>
                                                <div style={{ fontSize: "13px" }} className="text-secondary">Ages 0 to 2</div>

                                            </div>
                                            <div className="col-6">
                                                <div style={{ display: "flex", flexDirection: 'row' }}>
                                                    <button type="button" className='selectionbtn' onClick={infentDec} style={{ width: '30%' }}>
                                                        <i className="fa fa-minus-circle" aria-hidden="true"></i>
                                                    </button>
                                                    <div className="" style={{ width: "40%", textAlign: "center" }}>{infent}</div>
                                                    <button type="button" className='selectionbtn' onClick={InfentInc} style={{ width: '30%' }}>
                                                        <i className="fa fa-plus-circle" aria-hidden="true"></i>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                ) : ''
                            }
                        </div>
                        <div className="col-md-1">
                            <div className='search_7622'>
                                <i class="fa-solid fa-magnifying-glass"></i>
                            </div>
                        </div>
                    </div>


                    {/* <div className="inputsField_7622">

                </div> */}

                    {/* <CardIcon /> */}

                </div>
            </div>


            {/* <Main /> */}
        </>
    )
}

export default FlightBookingHeader

