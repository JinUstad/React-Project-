import React from "react";
import "./FlightDetails.css";
function FlightDetails() {
  return (
    <>
      <div className="flight_15622">
        {/* <div className="container">
          <div className="row">
            <div className="col-md-4"></div>

            <div className="col-md-8">
              <div className="listStyle_18622">
                    <div style={{marginLeft:"45px"}}>AIRLINE</div>
                    <div style={{marginLeft:"27px"}}>DEPARTURE</div>
                    <div style={{marginLeft:"26px"}}>DURATION</div>
                    <div style={{marginLeft:"45px"}}>ARRIVAL</div>
                    <div style={{marginLeft:"112px"}}>PRICE</div>
                <div style={{ marginLeft: "78px" }}>BEST VALUE</div>
              </div>


            </div>
          </div>
        </div> */}

        <div className="container">
          <div className="row">
            <div className="col-md-4 col-lg-4 col-4"></div>
            <div className="col-md-8 col-lg-8 col-12">
              <div className="listData_18622">
                <ul className=" floatSec_18622">
                  <li className=" float_18622   fghhhjghjjh">
                    <div style={{ display: "inline-flex" }}>
                      <img src="https://dhiz4uvf5rpaq.cloudfront.net/in/V2/assets/images/AirlineLogo/UK.jpg" alt="" style={{ width: "25px", height: "25px", marginTop: "10px", marginRight: "10px", marginLeft: "-20px" }} />
                      <div>
                        <span>Vistar</span><br />
                        <span className="bottmDate_16522">UK - 822</span>
                      </div>
                    </div>

                  </li>
                  <li className=" float_18622  hff465768790">
                    <span>09:45</span><br />
                    <span className="bottmDate_16522">Chennai</span>
                  </li>
                  <li className=" float_18622  hff465768790" style={{ marginTop: "auto", position: "relative" }}>
                    <span>14Hr. 05 Min</span><br />
                    <div className="lineDistance_18622"></div>
                    <i className="fa-solid fa-plane  plan_18622"></i><br />
                    <span className="bottmDate_16522">1 stop , via Mumbai</span>
                  </li>
                  <li className=" float_18622  hff465768790">
                    <span>23:50</span><br />
                    <span className="bottmDate_16522">Ahmedabad</span>
                  </li>
                  <li className=" float_18622  hff465768790">
                    <span><i class="fa-solid fa-location-pin"></i></span><br />
                    <span className="bottmDate_16522">dfhgjh</span>
                  </li>
                  <li className=" float_18622  hff465768790">
                    <span style={{ color: "black", fontWeight: "700" }}>₹ 9435</span><br />
                    <span className="bottmDate_16522" style={{ color: "#d40000" }}>ATFLY - 136 off</span>
                  </li>

                  <li className=" float_18622  hff465768790">
                    <button className="btn_18622">Book Now</button>
                    <span className="bottmDate_16522">+ Flight Detail</span>
                  </li>

                </ul>
                <hr />
              </div>

            </div>
          </div>
        </div>
      </div>

    </>
  );
}

export default FlightDetails;
