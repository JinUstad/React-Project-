import React, { useState } from 'react';
import { Link } from "react-router-dom"
import DatePicker from 'react-date-picker';
import './SearchBar.css'
import './FlightForm.css'
import SearchBarDate from './SearchBarDate';
import CardIcon from './CardIcon'
import { useNavigate } from 'react-router-dom'
import Main from './Main';


function FlightForm() {
    const navigate = useNavigate()

    const BookHotel = (e) => {
        navigate(`/flightSearch${e}`)
    }

    const [adults, SetAdults] = useState(1);
    const [kids, SetKids] = useState(0);
    const [infent, SetInfents] = useState(0);
    const [memberSelectionBool, SetmemberSelection] = useState(false)


    function adultInc() {
        if (adults < 12) {
            SetAdults(adults + 1);
        } else {
        }
    }
    function adultDec() {
        if (adults >= 2) {
            SetAdults(adults - 1);
        } else {
        }
    }
    function kidsInc() {
        if (kids < 12) {
            SetKids(kids + 1);
        } else {
        }
    }
    function kidsDec() {
        if (kids >= 1) {
            SetKids(kids - 1);
        } else {
        }
    }
    function InfentInc() {
        if (infent < 12) {
            SetInfents(infent + 1);
        } else {
        }
    }
    function infentDec() {
        if (infent >= 1) {
            SetInfents(infent - 1);
        } else {
        }
    }

    function showadult() {
        SetmemberSelection(!memberSelectionBool)
    }
    return (
        <>
            <div className="mainSection_8622">
                <div className="container " >
                    <div className="row mt-5 reverseCol_8622" >
                        <div className="col-md-6">
                            <div className='radio_8622'     >
                                <span>
                                    <input type="radio" name='cardbtn' className='' />
                                    <label className='text-white'>One Way</label>
                                </span>
                                <span style={{ display: "inline" }}>
                                    <input type="radio" name='cardbtn' className='' />
                                    <label className='text-white'>Round Trip</label>
                                </span>
                                <span>
                                    <input type="radio" name='cardbtn' className='' />
                                    <label className='text-white'>Multi City</label>
                                </span>
                            </div>
                        </div>


                        <div className="col-md-6">
                            <h2 className='hed_8622'>Book Flight Tickets</h2>
                        </div>
                    </div>
                    <hr style={{ color: "white" }} />
                    <div className="row chfhjfh   chfhjfh657">


                        <div className="col-md-2 colpadding_7622">
                            <div className="first_7622" style={{ position: "relative" }}>
                                <div className="row">
                                    <div className="col-md-2">
                                        <div className="icon_7622">
                                            <i class="fa-solid fa-users-line"></i>
                                        </div>
                                    </div>
                                    <div className="col-md-10" >
                                        <div className="input_7622"  >
                                            <p><b>From</b></p>
                                            <span className='guests_7622'>New Delhi</span>
                                            {/* <span>   <i class="fa-solid fa-arrow-right"></i></span> */}
                                        </div>
                                    </div>
                                    <div className='arrowSwipe_7622'>
                                        &#8644;
                                    </div>
                                </div>
                            </div>
                        </div>
                       
                        

                        <div className="col-md-2 colpadding_7622">
                            <div className="first_7622" style={{ position: "relative" }}>
                                <div className="row">
                                    <div className="col-md-2">
                                        <div className="icon_7622">
                                            <i class="fa-solid fa-users-line"></i>
                                        </div>
                                    </div>
                                    <div className="col-md-10" >
                                        <div className="input_7622" >
                                            <p><b>To</b></p>
                                            <span className='guests_7622'>Dasna</span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>


                        <div className="col-md-3 colpadding_7622" style={{ width: "20%" }}>
                            <div className="first_7622">
                                <div className="row">
                                    <div className="col-md-2">
                                        <div className="icon_7622" style={{ marginLeft: "5px" }}>
                                            <i class="fa-solid fa-calendar"></i>
                                        </div>
                                    </div>
                                    <div className="col-md-10">
                                        <div className="input_7622">
                                            <SearchBarDate />
                                            <span>Add Date/  <b style={{ color: "#ce1e1e" }}>DEPART</b></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="col-md-3 colpadding_7622" style={{ width: "20%" }} >
                            <div className="first_7622">
                                <div className="row">
                                    <div className="col-md-2">
                                        <div className="icon_7622" style={{ marginLeft: "5px" }}>
                                            <i class="fa-solid fa-calendar"></i>
                                        </div>
                                    </div>
                                    <div className="col-md-10">
                                        <div className="input_7622">
                                            <SearchBarDate />
                                            <span>Add Date/  <b style={{ color: "#ce1e1e" }}>RETURN</b></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div className="col-md-2 colpadding_7622">
                            <div className="first_7622" style={{ position: "relative" }}>
                                <div className="row">
                                    <div className="col-md-2">
                                        <div className="icon_7622">
                                            <i class="fa-solid fa-users-line"></i>
                                        </div>
                                    </div>
                                    <div className="col-md-10" >
                                        <div className="input_7622" onClick={showadult} >
                                            <p>Guests</p>
                                            <span className='guests_7622'>Add Guests</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            {
                                memberSelectionBool ? (
                                    <div className='gestSelection py-2 px-3' id="urstSelection">
                                        <div className="row ">
                                            <div className="col-6">
                                                <div style={{ fontSize: "14.5px", fontWeight: "500" }}>Adults</div>
                                                <div style={{ fontSize: "13px" }} className="text-secondary">Ages 13 or above</div>
                                            </div>
                                            <div className="col-6">
                                                <div style={{ display: "flex", flexDirection: 'row' }}>
                                                    <button className='selectionbtn' type="button" onClick={adultDec} style={{ width: '30%' }}>
                                                        <i className="fa fa-minus-circle" aria-hidden="true"></i>
                                                    </button>
                                                    <div className="" style={{ width: "40%", textAlign: "center" }}>{adults}</div>
                                                    <button className='selectionbtn' type="button" onClick={adultInc} style={{ width: '30%' }}>
                                                        <i className="fa fa-plus-circle" aria-hidden="true"></i>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                        <hr />
                                        <div className="row ">
                                            <div className="col-6">
                                                <div style={{ fontSize: "14.5px", fontWeight: "500" }}>Children</div>
                                                <div style={{ fontSize: "13px" }} className="text-secondary">Ages 2 to 12</div>
                                            </div>
                                            <div className="col-6">
                                                <div style={{ display: "flex", flexDirection: 'row' }}>
                                                    <button className='selectionbtn' type="button" onClick={kidsDec} style={{ width: '30%' }}>
                                                        <i className="fa fa-minus-circle" aria-hidden="true"></i>
                                                    </button>
                                                    <div className="" style={{ width: "40%", textAlign: "center" }}>{kids}</div>
                                                    <button type="button" className='selectionbtn' onClick={kidsInc} style={{ width: '30%' }}>
                                                        <i className="fa fa-plus-circle" aria-hidden="true"></i>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                        <hr />

                                        <div className="row ">
                                            <div className="col-6">
                                                <div style={{ fontSize: "14.5px", fontWeight: "500" }}>Infents</div>
                                                <div style={{ fontSize: "13px" }} className="text-secondary">Ages 0 to 2</div>

                                            </div>
                                            <div className="col-6">
                                                <div style={{ display: "flex", flexDirection: 'row' }}>
                                                    <button type="button" className='selectionbtn' onClick={infentDec} style={{ width: '30%' }}>
                                                        <i className="fa fa-minus-circle" aria-hidden="true"></i>
                                                    </button>
                                                    <div className="" style={{ width: "40%", textAlign: "center" }}>{infent}</div>
                                                    <button type="button" className='selectionbtn' onClick={InfentInc} style={{ width: '30%' }}>
                                                        <i className="fa fa-plus-circle" aria-hidden="true"></i>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                ) : ''
                            }
                        </div>
                        <div className="col-md-1">
                            <div className='search_7622'>
                                {/* <i class="fa-solid fa-magnifying-glass"></i> */}
                                <Link to="/flightSearch">   <button className='btnbtn_18622'>Search</button></Link>

                            </div>
                        </div>
                    </div>
                    <div className='flightCard_8622'>
                        <CardIcon />
                    </div>

                </div>
            </div>

            <Main />



            {/* adult================================================================================================================ */}


        </>
    )
}

export default FlightForm