


import React from 'react'
import './Footer.css'

function Footer() {
  return (
      <>
          <footer className='mt-4'>
              <div className="top_header">
                  <section>
                      <span><i className="fa fa-map-marker" /></span>
                      <span>Street, full address, state/province, country, pincode</span>
                  </section>
                  <section>
                      <span><i className="fa fa-phone" /></span>
                      <span>(00) 0000 0000</span>
                  </section>
                  <section>
                      <span><i className="fa fa-envelope" /></span>
                      <span>info@websitename.com</span>
                  </section>
              </div>
              <span className="border-shape" />
              <div className="bottom_content">
                  <section>
                      <a href="#"><i class="fa-brands fa-facebook-f"></i></a>
                      <a href="#"><i class="fa-brands fa-instagram"></i></a>
                      <a href="#"><i class="fa-brands fa-twitter"></i></a>
                      <a href="#"><i class="fa-brands fa-telegram"></i></a>
                  </section>
                  <section>
                      <a href="#">Home</a>
                      <a href="#">Flight</a>
                      <a href="#">Hotel</a>
                      <a href="#">Holidays</a>
                      <a href="#">Visa</a>
                      <a href="#">Contact Us</a>
                  </section>
              </div>
              <div className="copyright">
                  Copyright © 2021 websitename - All rights reserved
              </div>
          </footer>
      </>
  )
}

export default Footer
