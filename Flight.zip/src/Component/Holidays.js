import React from 'react'
import CardIcon from './CardIcon'
import SearchBarDate from './SearchBarDate'
import Main from './Main'


function Holidays() {
  return (
      <>
          <div className="mainSection_7622">
              <div className="container mt-4" >
                  <h2 className='text-center text-white'>Book Domestic and International Holiday Packages</h2>
                  <hr style={{ color: "white" }} />
                  <div className="row chfhjfh">
                      <div className="col-md-8 colpadding_7622">
                          <div className="first_7622">
                              <div className="row">
                                  <div className="col-md-2">
                                      <div className="icon_7622 icon_9622">
                                          <i class="fa-solid fa-location-dot" style={{marginLeft:"80px"}}></i>
                                      </div>
                                  </div>
                                  <div className="col-md-10">
                                      <div className="input2_7622">
                                          <input type="text" placeholder='Search..' className='form-control' />
                                          <span>FIND HOLIDAYS BY DESTINATION</span>
                                      </div>
                                  </div>
                              </div>
                          </div>
                      </div>

                   

                      <div className="col-md-3 colpadding_7622" >
                          <div className="first_7622">
                              <div className="row">
                                  <div className="col-md-2">
                                      <div className="icon_7622">
                                          <i class="fa-solid fa-calendar"></i>
                                      </div>
                                  </div>
                                  <div className="col-md-10">
                                      <div className="input_7622">
                                          <SearchBarDate />
                                          <span>STARTING ON  <b style={{ color: "#ce1e1e" }}>Any Time</b></span>
                                      </div>
                                  </div>
                              </div>
                          </div>
                      </div>

                     
                      <div className="col-md-1">
                          <div className='search_7622'>
                              <i class="fa-solid fa-magnifying-glass"></i>
                          </div>
                      </div>
                  </div>


                  <CardIcon />

              </div>
          </div>


          <Main/>
      </>
  )
}

export default Holidays



