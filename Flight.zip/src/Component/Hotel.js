import React from 'react'

function About() {
  return (
    <div>Hotel</div>
  )
}

export default About