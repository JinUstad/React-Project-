import React from 'react'
import './ImageGallery.css'
import SimpleImageSlider from "react-simple-image-slider";


function ImageGallery({setTimes}) {
    

    const images = [
        { url: "https://c4.wallpaperflare.com/wallpaper/750/566/555/costa-adeje-gran-hotel-4k-hd-computer-desktop-wallpaper-preview.jpg" },
        { url: "https://wallpaperaccess.com/full/6688071.jpg" },
        { url: "https://c4.wallpaperflare.com/wallpaper/624/380/1000/life-resort-hotel-resort-hotel-wallpaper-preview.jpg" },
        { url: "https://wallpapershome.com/images/pages/ico_h/659.jpg" },
        { url: "https://images.wallpaperscraft.com/image/single/maldives_tropical_underwater_hotel_82210_3840x2400.jpg" },
        { url: "https://images.unsplash.com/photo-1561501900-3701fa6a0864?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MXx8bHV4dXJ5JTIwaG90ZWx8ZW58MHx8MHx8&w=1000&q=80" },
        { url: "https://images6.alphacoders.com/349/thumb-1920-349835.jpg" },
    ];
    function myFunction() {
        setTimes(false)
    }
  return (
      <>
          <div className="ImageGallery_20622">
              <a className='timesPopUphide' onClick={myFunction}>&times;</a>
              <div className='imgGalleryHolder20622' style={{ margin: 'auto' }}>
                  <SimpleImageSlider
                      width={1200}
                      height={504}
                      images={images}
                      showBullets={true}
                      showNavs={true}

                  />  
              </div>
          </div>
      </>
  )
}

export default ImageGallery