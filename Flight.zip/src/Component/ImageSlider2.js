import React from 'react'
import Carousel from "react-multi-carousel";
import "react-multi-carousel/lib/styles.css";

function ImageSlider2() {
    const responsive = {
        superLargeDesktop: {
            // the naming can be any, depends on you.
            breakpoint: { max: 4000, min: 3000 },
            items: 5
        },
        desktop: {
            breakpoint: { max: 3000, min: 1024 },
            items: 3
        },
        tablet: {
            breakpoint: { max: 1024, min: 464 },
            items: 2
        },
        mobile: {
            breakpoint: { max: 464, min: 0 },
            items: 1
        }
    };
  return (
      <div className="container">
          <Carousel responsive={responsive} >
              
              <div className="imgSec_315210 m-2" >
                  <div className="row">
                      <div className="col-md-6">
                          <div className="dealsImage">
                              <img
                                  src="https://cf.bstatic.com/xdata/images/hotel/max1024x768/362029762.jpg?k=55ad53d4930548d727f7e97606641b23fd43de04af0e8c54d62534ce032dddde&o=&hp=1"
                                  alt=""
                                  style={{ width: "82%" }}
                              />
                          </div>
                      </div>
                      <div className="col-md-6">
                          <a href="">
                              <div className="dealText">
                                  <span className='highLight'> Free breakfast</span>
                                  <h6>Upto 50% Off on Hotels</h6>
                                  <p>Get upto 50%* Instant discount on any Hotel bookings</p>
                              </div>
                          </a>
                      </div>
                  </div>
              </div>

              <div className="imgSec_315210 m-2">
                  <div className="row">
                      <div className="col-md-6">
                          <div className="dealsImage">
                              <img
                                  src="https://cutewallpaper.org/25/best-hotels-wallpaper-hd/1861119110.jpg"
                                  alt=""
                                  style={{ width: "82%" }}
                              />
                          </div>
                      </div>
                      <div className="col-md-6">
                          <a href="">
                              <div className="dealText">
                                   <span className='highLight'> Free breakfast</span>
                                  <h6>Upto 50% Off on Hotels</h6>
                                  <p>Get upto 50%* Instant discount on any Hotel bookings</p>
                              </div>
                          </a>
                      </div>
                  </div>
              </div>
              
              <div className="imgSec_315210 m-2">
                  <div className="row">
                      <div className="col-md-6">
                          <div className="dealsImage">
                              <img
                                  src="https://media.architecturaldigest.com/photos/5bfd77647c86c80e83b4bc48/master/pass/4.%20An%20aerial%20view%20of%20Kudadoo%20Maldives%20which%20is%20the%20archipelago's%20first%20fully%20sustainable%20resort-%20credit%20Kudadoo%20by%20Hurawahli.jpg"
                                  alt=""
                                  style={{ width: "82%" }}
                              />
                          </div>
                      </div>
                      <div className="col-md-6">
                          <a href="">
                              <div className="dealText">
                                   <span className='highLight'> Free breakfast</span>
                                  <h6>Upto 50% Off on Hotels</h6>
                                  <p>Get upto 50%* Instant discount on any Hotel bookings</p>
                              </div>
                          </a>
                      </div>
                  </div>
              </div>
          </Carousel>
      </div>
  )
}

export default ImageSlider2