import React from 'react'
import Carousel from "react-multi-carousel";
import "react-multi-carousel/lib/styles.css";

function ImageSlider3() {
    const responsive = {
        superLargeDesktop: {
            // the naming can be any, depends on you.
            breakpoint: { max: 4000, min: 3000 },
            items: 5
        },
        desktop: {
            breakpoint: { max: 3000, min: 1024 },
            items: 3
        },
        tablet: {
            breakpoint: { max: 1024, min: 464 },
            items: 2
        },
        mobile: {
            breakpoint: { max: 464, min: 0 },
            items: 1
        }
    };
    return (
        <div className="container">
            <Carousel responsive={responsive}>
                <div className="imgSec_315210 m-2" >
                    <div className="row">

                        <div className="col-md-6">
                            <div className="dealsImage">
                                <img
                                    src="https://w0.peakpx.com/wallpaper/538/457/HD-wallpaper-luxury-hotel-lobby-r-hotel-lobby-sofas-chandeliers.jpg"
                                    alt=""
                                    style={{ width: "82%" }}
                                />
                            </div>
                        </div>
                        <div className="col-md-6">
                            <a href="">
                                <div className="dealText">
                                     <span className='highLight'> Free breakfast</span>
                                    <h6>Upto 50% Off on Hotels</h6>
                                    <p>Get upto 50%* Instant discount on any Hotel bookings</p>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
                <div className="imgSec_315210 m-2">
                    <div className="row">

                        <div className="col-md-6">
                            <div className="dealsImage">
                                <img
                                    src="https://images7.alphacoders.com/362/362619.jpg"
                                    alt=""
                                    style={{ width: "82%" }}
                                />
                            </div>
                        </div>
                        <div className="col-md-6">
                            <a href="">
                                <div className="dealText">
                                     <span className='highLight'> Free breakfast</span>
                                    <h6>Upto 50% Off on Hotels</h6>
                                    <p>Get upto 50%* Instant discount on any Hotel bookings</p>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
                <div className="imgSec_315210 m-2">
                    <div className="row">

                        <div className="col-md-6">
                            <div className="dealsImage">
                                <img
                                    src="https://images.wallpaperscraft.com/image/single/living_room_hotel_furniture_interior_flowers_paintings_sofas_94729_3840x2160.jpg"
                                    alt=""
                                    style={{ width: "82%" }}
                                />
                            </div>
                        </div>
                        <div className="col-md-6">
                            <a href="">
                                <div className="dealText">
                                     <span className='highLight'> Free breakfast</span>
                                    <h6>Upto 50% Off on Hotels</h6>
                                    <p>Get upto 50%* Instant discount on any Hotel bookings</p>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
            </Carousel>
        </div>
    )
}

export default ImageSlider3