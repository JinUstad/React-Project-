import React from 'react'
import Carousel from "react-multi-carousel";
import "react-multi-carousel/lib/styles.css";

function ImageSlider4() {
    const responsive = {
        superLargeDesktop: {
            // the naming can be any, depends on you.
            breakpoint: { max: 4000, min: 3000 },
            items: 5
        },
        desktop: {
            breakpoint: { max: 3000, min: 1024 },
            items: 3
        },
        tablet: {
            breakpoint: { max: 1024, min: 464 },
            items: 2
        },
        mobile: {
            breakpoint: { max: 464, min: 0 },
            items: 1
        }
    };
    return (
        <div className="container">
            <Carousel responsive={responsive}>
                <div className="imgSec_315210 m-2" >
                    <div className="row">

                        <div className="col-md-6">
                            <div className="dealsImage">
                                <img
                                    src="https://assets.vogue.com/photos/5d49d4c2a3afbe0008d8de44/master/w_3000,h_1674,c_limit/00-story-image-raffles-hotel-singapore.jpg"
                                    alt=""
                                    style={{ width: "82%" }}
                                />
                            </div>
                        </div>
                        <div className="col-md-6">
                            <a href="">
                                <div className="dealText">
                                    <span className='highLight'> Free breakfast</span>
                                    <h6>Upto 50% Off on Hotels</h6>
                                    <p>Get upto 50%* Instant discount on any Hotel bookings</p>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
                <div className="imgSec_315210 m-2">
                    <div className="row">

                        <div className="col-md-6">
                            <div className="dealsImage">
                                <img
                                    src="https://wallpaperaccess.com/full/1593222.jpg"
                                    alt=""
                                    style={{ width: "82%" }}
                                />
                            </div>
                        </div>
                        <div className="col-md-6">
                            <a href="">
                                <div className="dealText">
                                     <span className='highLight'> Free breakfast</span>
                                    <h6>Upto 50% Off on Hotels</h6>
                                    <p>Get upto 50%* Instant discount on any Hotel bookings</p>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
                <div className="imgSec_315210 m-2">
                    <div className="row">

                        <div className="col-md-6">
                            <div className="dealsImage">
                                <img
                                    src="https://dynamic-media-cdn.tripadvisor.com/media/photo-o/11/75/74/ab/rooftop-swimming-pool.jpg?w=900&h=-1&s=1"
                                    alt=""
                                    style={{ width: "82%" }}
                                />
                            </div>
                        </div>
                        <div className="col-md-6">
                            <a href="">
                                <div className="dealText">
                                     <span className='highLight'> Free breakfast</span>
                                    <h6>Upto 50% Off on Hotels</h6>
                                    <p>Get upto 50%* Instant discount on any Hotel bookings</p>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
            </Carousel>
        </div>
    )
}

export default ImageSlider4