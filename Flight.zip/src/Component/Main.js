import React from 'react'
import CardIcon from './CardIcon'
import ExclusiveDeals from './ExclusiveDeals'
import PopularDestinations from './PopularDestinations'
import TravelStories from './TravelStories'
function Main() {
  return (
    <div>
      <ExclusiveDeals />
      <PopularDestinations />
      <TravelStories />
    </div>
  )
}

export default Main