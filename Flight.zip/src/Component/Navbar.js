import React, { useState, useEffect } from 'react';
import './Navbar.css'
function Navbar() {
  const [toggle, settoggle] = useState(false)

  useEffect(() => {
    if (window.innerWidth> 765) {
      settoggle(true)
    }
    else {
      settoggle(false)
    }
  }, [])
  


  return (
    <>
      <nav className="navbar navbar_24622 navbar-expand-lg ">
        <img src={process.env.PUBLIC_URL + '/Assets/yo.png'} alt="" />

        {/* <a
          className="navbar-brand text-white" href="#" >
          Touroxy
        </a> */}
        <button
          className="navbar-toggler"
          type="button"
          data-toggle="collapse"
          data-target="#navbarSupportedContent"
          aria-controls="navbarSupportedContent"
          aria-expanded="false"
          aria-label="Toggle navigation"

          onClick={() => settoggle(!toggle)}
        >
          <span className="navbar-toggler-icon" />
        </button>
        {
          toggle && (
            <div className="collapse_22622 navbar-collapse" id="navbarSupportedContent" >
              <ul className="navbar-nav mr-auto">
                <li className="navitem_22622  ">
                  <a className="nav-link text-center text-white" href="/flight">

                    <i className="fa fa-plane"></i> <p>Flight</p>
                    <span className="sr-only">(current)</span>
                  </a>
                </li>
                <li className="navitem_22622 ">
                  <a className="nav-link text-center text-white" href="/hotels">
                    <i className="fa fa-hotel"></i>
                    <p>Hotel</p>
                  </a>
                </li>
                <li className="navitem_22622 ">
                  <a className="nav-link text-center text-white" href="/holiday">
                    <i className="fa-solid fa-tree"></i>
                    <p>Holiday</p>
                  </a>
                </li>
                <li className="navitem_22622 ">
                  <a className="nav-link text-center text-white" href="#">
                    <i className="fa fa-passport"></i>
                    <p>Visa</p>
                  </a>
                </li>
                <li className="navitem_22622 ">
                  <a className="nav-link text-center text-white" href="#">
                    <i className="fa fa-passport"></i>
                    <p>Visa</p>
                  </a>
                </li>
              </ul>


              <span className='dropdownmenu_22622'>
                <li class="navitem_22622 dropdown">
                  <div class="nav-link dropdown-toggle dropdownToggle_22622" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown">
                    ₹ INR
                  </div>
                  <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                    <a class="dropdown-item" href="#">Action</a>
                    <a class="dropdown-item" href="#">Another action</a>
                    <a class="dropdown-item" href="#">Something else here</a>
                  </div>
                </li>
              </span>
              <span className='dropdownmenu_22622'>
                <li class="navitem_22622 dropdown">
                  <div class="nav-link dropdown-toggle dropdownToggle_22622" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    COUNTRY
                  </div>
                  <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                    <a class="dropdown-item" href="#">Action</a>
                    <a class="dropdown-item" href="#">Another action</a>
                    <a class="dropdown-item" href="#">Something else here</a>
                  </div>
                </li>
              </span>
              <span className='dropdownmenu_22622'>
                <li class="navitem_22622 dropdown">
                  <div class="nav-link dropdown-toggle dropdownToggle_22622" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    LOGIN/SIGNUP
                  </div>
                  <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                    <a class="dropdown-item" href="#">LogIn</a>
                    <a class="dropdown-item" href="#">Register</a>
                    <a class="dropdown-item" href="#">Something else here</a>
                  </div>
                </li>
              </span>
            </div>
          )
        }

      </nav>
    </>
  );
}

export default Navbar