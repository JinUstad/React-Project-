import React, { useState, useEffect } from "react";
import "./FlightDetails.css";
import tabUtil from "./Tab";
import FlightJsonData from "./FlightJsonData";
import { convertTime } from "./Tab";
function FlightSec() {
  const [showdata, setShowdata] = useState(false);
  const [jsonData, setJsonData] = useState(FlightJsonData);

 

  useEffect(() => {
    if (showdata) {
      document.getElementById('bydefaultTab').click();
    }
  }, [showdata])

  function handleCallTab(event, tabName) {
    var tab, btn, activeClass;
    activeClass = 'active';
    tab = document.getElementsByClassName("overview206");
    btn = document.getElementsByClassName("callTab");
    tabUtil(event, tabName, tab, btn, activeClass);
  }





  return (
    <>
    
      {/* <h1>wahid start-==============================================================</h1> */}
      {
        jsonData.map((person1, index) => (
          person1.fareFlightSegment.map((fareFlightSegment) => (
            fareFlightSegment.flightSegmentsGroups.map((person3) => (
              person3.flightSegments.map((person4) => (
                person4.segments.map((item) => (

                  <div className="flightSec ">

                    <div className="airFlightdetails">
                      <div className="table-responsive">
                        <table className="table  tableColor">
                          <thead>
                            <tr>
                              <th scope="col">AIRLINE</th>
                              <th scope="col">DEPARTURE</th>
                              <th scope="col">DURATION</th>
                              <th scope="col">ARRIVAL</th>
                              <th scope="col">PRICE </th>
                              <th scope="col">BEST VALUE</th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr className="tableRow123">


                              <th scope="row" className="flightDetail16">
                                <img
                                  src="https://dhiz4uvf5rpaq.cloudfront.net/images/airline-logos/G8.jpg?V1"
                                  alt=""
                                />
                                <span className="airAsia">
                                  <h6>{item.carrier.name}</h6>
                                </span>
                                <p>{item.carrier.code}</p>
                                <strong>Best Value</strong>
                              </th>




                              <td>
                                <div className="departure">
                                  <h6>{item.depTime}</h6>
                                  <p>{item.oriName}</p>
                                </div>
                              </td>



                              <td>
                                <div className="duration duration12">
                                  <li className=" float_18622 " style={{ marginTop: "auto", position: "relative", listStyle: "none" }}>
                                    {/* <span>{Math.floor(item.duration / 60),":",item.duration/60 - Math.floor(item.duration/60)}</span><br /> */}
                                    <span>{convertTime(item.duration)} Minutes</span><br />
                                    <div className="lineDistance_455622"></div>
                                    <i className="fa-solid fa-plane  plan_19622"></i><br />
                                    <span className="bottmDate_19522">{item.stops } stop , via Mumbai</span>
                                  </li>
                                </div>
                              </td>



                              <td>
                                <div className="arrival">
                                  <h6>{ item.arrTime}</h6>
                                  <h5>
                                    { item.destName} <span className="text-danger">7 LEFT</span>
                                  </h5>
                                  <p>Next Day</p>
                                </div>
                              </td>


                              <td>
                                <div className="price">
                                  <h6>₹ {fareFlightSegment.basePrice }</h6>
                                </div>
                              </td>
                              <td>
                                <div className="btn">
                                  <div className="btn btn-danger">Book Now</div>
                                  <p onClick={() => setShowdata(!showdata)}>Flight</p>
                                </div>
                              </td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                      <div className="flightaccordi">
                        {showdata && (
                          <div className="flightshowdata1234">
                            <div className="mb-4">
                              <ul>
                                <li className="callTab" id="bydefaultTab" onClick={(event) => handleCallTab(event, "first")} > OVERVIEW </li>
                                <li className="callTab" onClick={(event) => handleCallTab(event, "second")}>FARE SUMMARY And RULES </li>
                                <li className="callTab" onClick={(event) => handleCallTab(event, "third")} > FREE BAGGAGE </li>
                              </ul>

                              <div className="overview206" id="first">
                                <div className="row">
                                  <div className="col-md-4">

                                    <div className="Timing_20622">
                                      <h5>{item.depTime}</h5>
                                      <h6>{item.depDate}</h6>
                                      <span>{item.oriName}</span>
                                      <span>{item.oriAirportName}</span>
                                    </div>


                                  </div>
                                  <div className="col-md-4">
                                    <li className=" float_18622  hff465768790" style={{ marginTop: "auto" }}>
                                      <div className="lineDistance_22622"></div>
                                      <i className="fa-solid fa-plane  plan_22622"></i>

                                    </li>
                                  </div>
                                  <div className="col-md-4">

                                    <div className="Timing1_20622">
                                      <h5>{item.arrTime}</h5>
                                      <h6>{item.depDate}</h6>
                                      <span>{item.destName}</span><br />
                                      <span>{item.destAirportName}</span>
                                    </div>


                                  </div>
                                </div>
                              </div>
                            </div>
                            <div className="overview206" id="second">
                              <div className="FARESUMMARY">
                                <div className="row">
                                  <div className="col-md-5">
                                    <div className="fareDetails">
                                      <p>Fare Details</p>
                                      <div>
                                        <details classname="details_comp20622" style={{ padding: "6px", boxShadow: "0 0 9px 0 rgb(0 0 0 / 10%)" }}>
                                          <hr />
                                          <summary classname="summary_colapse20622 "  >
                                            Base Fare     <span style={{ float: "right" }}>₹ {fareFlightSegment.basePrice }</span>
                                          </summary>
                                          <p style={{ fontSize: "14px", marginBottom: "0px" }}>   Adult (1 X ₹  {fareFlightSegment.basePrice})    <span style={{ float: "right" }}>₹  {fareFlightSegment.basePrice}</span></p>
                                        </details>

                                        <details classname="details_comp20622" style={{ padding: "6px", boxShadow: "0 0 9px 0 rgb(0 0 0 / 10%)", marginTop: "10px" }}>
                                          <hr />
                                          <summary classname="summary_colapse20622 ">
                                            Tax And Charges     <span style={{ float: "right" }}>₹ {fareFlightSegment.taxes}</span>
                                          </summary>
                                          <p style={{ fontSize: "14px", marginBottom: "0px" }}>   Total Amount   <span style={{ float: "right" }}>₹ {fareFlightSegment.totalPrice}</span></p>
                                        </details>
                                      </div>

                                    </div>
                                  </div>
                                  <div className="col-md-7">
                                    <div className="fareRules">
                                      <p>Fare Rules</p>
                                      <div className="tableOuter_21622">
                                        <table className="table">
                                          <thead className="thead-light">
                                            <tr style={{ lineHeight: "10px" }}>
                                              <th scope="col">CCU  BLR</th>
                                              <th scope="col">ADULT</th>
                                            </tr>
                                          </thead>
                                          <tbody style={{ borderTop: "none" }}>
                                            <p style={{ fontWeight: "500", fontSize: "14px", color: "blue", padding: "6px", marginTop: "10px", marginBottom: "0px" }}>Cancellation Fee</p>
                                            <tr>
                                              <td>0 HRS - 4 HRS To Departure</td>
                                              <td>Non Refundable</td>
                                            </tr>
                                            <tr>
                                              <td>4 HRS - 3 Days To Departure</td>
                                              <td>₹ 3500</td>
                                            </tr>
                                            <tr>
                                              <td>3 Days - 500 Days To Departure</td>
                                              <td>₹ 3000</td>
                                            </tr>
                                          </tbody>
                                          <tbody style={{ borderTop: "none" }}>
                                            <p style={{ fontWeight: "500", fontSize: "14px", color: "blue", padding: "6px", marginTop: "10px", marginBottom: "0px" }}>Cancellation Fee</p>
                                            <tr>
                                              <td>0 HRS - 4 HRS To Departure</td>
                                              <td>Non Refundable</td>
                                            </tr>
                                            <tr>
                                              <td>4 HRS - 3 Days To Departure</td>
                                              <td>₹ 3500</td>
                                            </tr>
                                            <tr>
                                              <td>3 Days - 500 Days To Departure</td>
                                              <td>₹ 3000</td>
                                            </tr>
                                          </tbody>
                                        </table>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div className="overview206" id="third">
                              <div className="freeBaggeTab620">
                                <table className="table">
                                  <thead clclassName="thead-light">
                                    <tr>
                                      <th scope="col">Sector/Flight</th>
                                      <th scope="col">Check in Baggage</th>
                                      <th scope="col">Cabin Baggage</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    <tr>
                                      <td>MAA - BOM</td>
                                      <td>There Is No Items</td>
                                      <td>There Is No Items</td>
                                    </tr>
                                    <tr>
                                      <td>BOM - AMD</td>
                                      <td>There Is No Items</td>
                                      <td>There Is No Items</td>
                                    </tr>
                                  </tbody>
                                </table>
                                <div className="ulDetails">
                                  <p>
                                    The information presented above is as obtained from
                                    the airline reservation system. Akbartravels.com
                                    does not guarantee the accuracy of this information.
                                  </p>
                                  <p>
                                    The baggage allowance may vary according to
                                    stop-overs, connecting flights and changes in
                                    airline rules.
                                  </p>
                                </div>
                                <div className="tabWornning">
                                  <p>
                                    {" "}
                                    <i className="fa fa-warning mr-2 text-danger"></i>{" "}
                                    Additional baggage cannot be added on this fare.
                                  </p>
                                </div>
                              </div>
                            </div>
                          </div>
                        )}
                      </div>
                      {/* <div className="tableParaDetail">
                        <p>
                          <span className="tableInfo">Info</span> All passengers are
                          requested to administer 2 doses of accepted vaccine before
                          commencement of any..
                        </p>
                      </div> */}
                    </div>
                  </div>

                ))
              ))
            ))
          ))
        ))
      }

      {/* <div className="flightSec ">
       
            <div className="airFlightdetails">
              <div className="table-responsive">
                <table class="table  tableColor">
                  <thead>
                    <tr>
                      <th scope="col">AIRLINE</th>
                      <th scope="col">DEPARTURE</th>
                      <th scope="col">DURATION</th>
                      <th scope="col">ARRIVAL</th>
                      <th scope="col">PRICE </th>
                      <th scope="col">BEST VALUE</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="tableRow123">

                     
                          <th scope="row" className="flightDetail16">
                            <img
                              src="https://dhiz4uvf5rpaq.cloudfront.net/images/airline-logos/G8.jpg?V1"
                              alt=""
                            />
                            <span className="airAsia">
                              <h6>airport name</h6>
                            </span>
                            <p>l5 749</p>
                            <strong>Best Value</strong>
                          </th>
                    


                     
                          <td>
                            <div className="departure">
                              <h6>depTime</h6>
                              <p>ori name</p>
                            </div>
                          </td>
                   

                    
                          <td>
                            <div className="duration duration12">
                              <li className=" float_18622 " style={{ marginTop: "auto", position: "relative", listStyle: "none" }}>
                                <span>time duraton</span><br />
                                <div className="lineDistance_455622"></div>
                                <i className="fa-solid fa-plane  plan_19622"></i><br />
                                <span className="bottmDate_19522">1 stop , via Mumbai</span>
                              </li>
                            </div>
                          </td>
                      

                    
                          <td>
                            <div className="arrival">
                              <h6>arr time</h6>
                              <h5>
                              dest name <span className="text-danger">7 LEFT</span>
                              </h5>
                              <p>Next Day</p>
                            </div>
                          </td>
                     

                      <td>
                        <div className="price">
                          <h6>₹ total price</h6>
                        </div>
                      </td>
                      <td>
                        <div className="btn">
                          <div className="btn btn-danger">Book Now</div>
                          <p onClick={() => setShowdata(!showdata)}>Flight</p>
                        </div>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <div className="flightaccordi">
                {showdata && (
                  <div className="flightshowdata1234">
                    <div className="mb-4">
                      <ul>
                        <li className="callTab" id="bydefaultTab" onClick={(event) => handleCallTab(event, "first")} > OVERVIEW </li>
                        <li className="callTab" onClick={(event) => handleCallTab(event, "second")}>FARE SUMMARY And RULES </li>
                        <li className="callTab" onClick={(event) => handleCallTab(event, "third")} > FREE BAGGAGE </li>
                      </ul>

                      <div className="overview206" id="first">
                        <div className="row">
                          <div className="col-md-4">
                          
                                <div className="Timing_20622">
                                  <h5>dep time</h5>
                                  <h6>dept data</h6>
                                  <span>dest name</span>
                                  <span>Netaji Subhas Chandra |Kolkata |IN |India</span>
                                </div>
                           

                          </div>
                          <div className="col-md-4">
                            <li className=" float_18622  hff465768790" style={{ marginTop: "auto" }}>
                              <div className="lineDistance_22622"></div>
                              <i className="fa-solid fa-plane  plan_22622"></i>

                            </li>
                          </div>
                          <div className="col-md-4">
                            
                                <div className="Timing1_20622">
                                  <h5>arr time</h5>
                                  <h6>arr date</h6>
                                  <span>ori name</span><br />
                                  <span>Netaji Subhas Chandra |Kolkata |IN |India</span>
                                </div>
                            

                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="overview206" id="second">
                      <div className="FARESUMMARY">
                        <div className="row">
                          <div className="col-md-5">
                            <div className="fareDetails">
                              <p>Fare Details</p>
                              <div>
                                <details classname="details_comp20622" style={{ padding: "6px", boxShadow: "0 0 9px 0 rgb(0 0 0 / 10%)" }}>
                                  <hr />
                                  <summary classname="summary_colapse20622 "  >
                                    Base Fare     <span style={{ float: "right" }}>₹ 345678</span>
                                  </summary>
                                  <p style={{ fontSize: "14px", marginBottom: "0px" }}>   Adult (1 X ₹ 7254)    <span style={{ float: "right" }}>₹ 345678</span></p>
                                </details>

                                <details classname="details_comp20622" style={{ padding: "6px", boxShadow: "0 0 9px 0 rgb(0 0 0 / 10%)", marginTop: "10px" }}>
                                  <hr />
                                  <summary classname="summary_colapse20622 ">
                                    Tax And Charges     <span style={{ float: "right" }}>₹ 4987</span>
                                  </summary>
                                  <p style={{ fontSize: "14px", marginBottom: "0px" }}>   Adult (1 X ₹ 7254)    <span style={{ float: "right" }}>₹ 345678</span></p>
                                </details>
                              </div>

                            </div>
                          </div>
                          <div className="col-md-7">
                            <div className="fareRules">
                              <p>Fare Rules</p>
                              <div className="tableOuter_21622">
                                <table class="table">
                                  <thead class="thead-light">
                                    <tr style={{ lineHeight: "10px" }}>
                                      <th scope="col">CCU  BLR</th>
                                      <th scope="col">ADULT</th>
                                    </tr>
                                  </thead>
                                  <tbody style={{ borderTop: "none" }}>
                                    <p style={{ fontWeight: "500", fontSize: "14px", color: "blue", padding: "6px", marginTop: "10px", marginBottom: "0px" }}>Cancellation Fee</p>
                                    <tr>
                                      <td>0 HRS - 4 HRS To Departure</td>
                                      <td>Non Refundable</td>
                                    </tr>
                                    <tr>
                                      <td>4 HRS - 3 Days To Departure</td>
                                      <td>₹ 3500</td>
                                    </tr>
                                    <tr>
                                      <td>3 Days - 500 Days To Departure</td>
                                      <td>₹ 3000</td>
                                    </tr>
                                  </tbody>
                                  <tbody style={{ borderTop: "none" }}>
                                    <p style={{ fontWeight: "500", fontSize: "14px", color: "blue", padding: "6px", marginTop: "10px", marginBottom: "0px" }}>Cancellation Fee</p>
                                    <tr>
                                      <td>0 HRS - 4 HRS To Departure</td>
                                      <td>Non Refundable</td>
                                    </tr>
                                    <tr>
                                      <td>4 HRS - 3 Days To Departure</td>
                                      <td>₹ 3500</td>
                                    </tr>
                                    <tr>
                                      <td>3 Days - 500 Days To Departure</td>
                                      <td>₹ 3000</td>
                                    </tr>
                                  </tbody>
                                </table>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="overview206" id="third">
                      <div className="freeBaggeTab620">
                        <table class="table">
                          <thead class="thead-light">
                            <tr>
                              <th scope="col">Sector/Flight</th>
                              <th scope="col">Check in Baggage</th>
                              <th scope="col">Cabin Baggage</th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr>
                              <td>MAA - BOM</td>
                              <td>There Is No Items</td>
                              <td>There Is No Items</td>
                            </tr>
                            <tr>
                              <td>BOM - AMD</td>
                              <td>There Is No Items</td>
                              <td>There Is No Items</td>
                            </tr>
                          </tbody>
                        </table>
                        <div className="ulDetails">
                          <p>
                            The information presented above is as obtained from
                            the airline reservation system. Akbartravels.com
                            does not guarantee the accuracy of this information.
                          </p>
                          <p>
                            The baggage allowance may vary according to
                            stop-overs, connecting flights and changes in
                            airline rules.
                          </p>
                        </div>
                        <div className="tabWornning">
                          <p>
                            {" "}
                            <i className="fa fa-warning mr-2 text-danger"></i>{" "}
                            Additional baggage cannot be added on this fare.
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
              <div className="tableParaDetail">
                <p>
                  <span className="tableInfo">Info</span> All passengers are
                  requested to administer 2 doses of accepted vaccine before
                  commencement of any..
                </p>
              </div>
            </div>
      </div> */}
        {/* <h1>wahid start-==============================================================</h1> */}
      

    </>
  )
}

export default FlightSec