import React, { useEffect } from "react";
import "./PopularDestinations.css";
import { useNavigate } from 'react-router-dom'

function PopularDestinations() {

  const navigate = useNavigate()

  const redirectOntour = (e) => {
    navigate(`/hotels${e}`)
  }


  useEffect(() => {
    document.getElementById('byDefaultOpen').click()
  }, [])

  function tabConfun(event, tabname) {
    var btn, tab;
    tab = document.getElementsByClassName('tabsCon');
    btn = document.getElementsByClassName('popularHover');

    for (var i = 0; i < tab.length; i++) {
      tab[i].style.display = "none";
    }
    for (var j = 0; j < btn.length; j++) {
      btn[j].className = btn[j].className.replace(' active', '');
    }
    document.getElementById(tabname).style.display = "block";
    event.currentTarget.classList += " active";

  }
  return (
    <>
      <div className="PopularDestinations mt-3">
        <span className="popular">
          Popular <b>Destinations</b>
        </span> <div className="viewDetails float-right" ><u>View All</u></div>
        <section class='FlexContainer_7722'>
          <div className="popularHover" id="byDefaultOpen" onClick={(event) => tabConfun(event, 'first')}>ALL DESTINATIONS</div>
          <div className="popularHover" onClick={(event) => tabConfun(event, 'second')}>INTERNATIONAL</div>
          <div className="popularHover" onClick={(event) => tabConfun(event, 'third')}>DOMESTIC</div>
        </section>
        <hr />
        <div className="tabsCon" id='first'>
          <div className="row  mt-5" >
            <div className=" col-md-6 mt-3">
              <div className="countryList">
                <ul>
                  {/* {Array(16)
                    .fill()
                    .map((_, i) => ( */}
                      <li>
                        <img src="https://cdn.pixabay.com/photo/2014/11/21/17/27/frog-540812_960_720.jpg" alt="" />
                        <span>India</span>
                      </li>
                      <li>
                    <img src="https://dhiz4uvf5rpaq.cloudfront.net/deal-files/deal-images/IN/destinations/hotel/Domestic/webp/manali.webp" alt="" />
                        <span>Manali</span>
                      </li>
                      <li>
                    <img src="https://dhiz4uvf5rpaq.cloudfront.net/deal-files/deal-images/IN/destinations/hotel/International/webp/bali.webp" alt="" />
                        <span>Bali</span>
                      </li>
                      <li>
                    <img src="https://dhiz4uvf5rpaq.cloudfront.net/deal-files/deal-images/IN/destinations/hotel/Domestic/webp/munnar.webp" alt="" />
                        <span>Munner</span>
                      </li>
                      <li>
                    <img src="https://dhiz4uvf5rpaq.cloudfront.net/deal-files/deal-images/IN/destinations/hotel/International/webp/dubai.webp" alt="" />
                        <span>Dubai</span>
                      </li>
                      <li>
                    <img src="https://dhiz4uvf5rpaq.cloudfront.net/deal-files/deal-images/IN/destinations/hotel/Domestic/webp/hyderabad.webp" alt="" />
                    <span>Hyderabad</span>
                      </li>
                      <li>
                    <img src="https://dhiz4uvf5rpaq.cloudfront.net/deal-files/deal-images/IN/destinations/hotel/International/webp/bahrain.webp" alt="" />
                        <span>Bahrain</span>
                      </li>
                      <li>
                    <img src="https://dhiz4uvf5rpaq.cloudfront.net/deal-files/deal-images/IN/destinations/hotel/Domestic/webp/kolkata.webp" alt="" />
                        <span>Kolkata</span>
                      </li>
                      <li>
                    <img src="https://dhiz4uvf5rpaq.cloudfront.net/deal-files/deal-images/IN/destinations/hotel/International/webp/kuala-lumpur.webp" alt="" />
                        <span>Kuala Lampur</span>
                      </li>
                      <li>
                    <img src="https://dhiz4uvf5rpaq.cloudfront.net/deal-files/deal-images/IN/destinations/hotel/Domestic/webp/chennai.webp" alt="" />
                        <span>Chennai</span>
                      </li>
                      <li>
                    <img src="https://dhiz4uvf5rpaq.cloudfront.net/deal-files/deal-images/IN/destinations/hotel/International/webp/berlin.webp" alt="" />
                        <span>Berlin</span>
                      </li>
                    {/* ))} */}
                </ul>
              </div>
            </div>
            <div className=" col-md-6">
              <div className="row">
                <div className="col-md-6">
                  <div className="item_9622" onClick={() => redirectOntour('-Tour')}>
                    <img src="https://cdn.pixabay.com/photo/2013/10/16/18/47/sea-196429_960_720.jpg" alt="Image" />
                    <div className="textOnImg_9622">London</div>
                    <div className="item-overlay top" />
                  </div>
                </div>
                <div className="col-md-6">
                  <div className="item_9622">
                    <img src="https://cdn.pixabay.com/photo/2013/10/16/18/43/hawaii-196425_960_720.jpg" alt="Image" />
                    <div className="textOnImg_9622">London</div>
                    <div className="item-overlay top" />
                  </div>
                </div>
                <div className="col-md-6">
                  <div className="item_9622">
                    <img src="https://cdn.pixabay.com/photo/2013/10/16/18/43/turtle-196424_960_720.jpg" alt="Image" />
                    <div className="textOnImg_9622">London</div>
                    <div className="item-overlay top" />
                  </div>
                </div>
                <div className="col-md-6">
                  <div className="item_9622">
                    <img src="https://cdn.pixabay.com/photo/2013/11/01/11/13/dolphin-203875_960_720.jpg" alt="Image" />
                    <div className="textOnImg_9622">London</div>
                    <div className="item-overlay top" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div className="tabsCon" id='second'>
          <div className="row  mt-5" >
            <div className=" col-md-6 mt-3">
              <div className="countryList">
                <ul>
                  {Array(16)
                    .fill()
                    .map((_, i) => (
                      <li>
                        <img
                          src="https://c4.wallpaperflare.com/wallpaper/814/350/568/spa-beach-hotel-infinity-pool-wallpaper-preview.jpg"
                          alt=""
                        />
                        <span>India</span>
                      </li>
                    ))}
                </ul>
              </div>
            </div>
            <div className=" col-md-6">
              <div className="row">
                <div className="col-md-6">
                  <div className="item_9622" onClick={() => redirectOntour('-Tour')}>
                    <img src="https://c4.wallpaperflare.com/wallpaper/624/380/1000/life-resort-hotel-resort-hotel-wallpaper-preview.jpg" alt="Image" />
                    <div className="textOnImg_9622">London</div>
                    <div className="item-overlay top" />
                  </div>
                </div>
                <div className="col-md-6">
                  <div className="item_9622">
                    <img src="https://cdn.pixabay.com/photo/2013/10/16/18/43/hawaii-196425_960_720.jpg" alt="Image" />
                    <div className="textOnImg_9622">London</div>
                    <div className="item-overlay top" />
                  </div>
                </div>
                <div className="col-md-6">
                  <div className="item_9622">
                    <img src="https://cdn.pixabay.com/photo/2013/10/16/18/43/turtle-196424_960_720.jpg" alt="Image" />
                    <div className="textOnImg_9622">London</div>
                    <div className="item-overlay top" />
                  </div>
                </div>
                <div className="col-md-6">
                  <div className="item_9622">
                    <img src="https://cdn.pixabay.com/photo/2013/11/01/11/13/dolphin-203875_960_720.jpg" alt="Image" />
                    <div className="textOnImg_9622">London</div>
                    <div className="item-overlay top" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="tabsCon" id='third'>
          <div className="row  mt-5" >
            <div className=" col-md-6 mt-3">
              <div className="countryList">
                <ul>
                  {Array(16)
                    .fill()
                    .map((_, i) => (
                      <li>
                        <img
                          src="https://wallpapershome.com/images/wallpapers/hotel-costa-dei-fiori-5120x2880-5k-4k-wallpaper-sardinia-italy-5746.jpg"
                          alt=""
                        />
                        <span>India</span>
                      </li>
                    ))}
                </ul>
              </div>
            </div>
            <div className=" col-md-6">
              <div className="row">
                <div className="col-md-6">
                  <div className="item_9622" onClick={() => redirectOntour('-Tour')}>
                    <img src="https://c4.wallpaperflare.com/wallpaper/665/611/681/swimming-pool-landscape-sea-greece-wallpaper-preview.jpg" alt="Image" />
                    <div className="textOnImg_9622">London</div>
                    <div className="item-overlay top" />
                  </div>
                </div>
                <div className="col-md-6">
                  <div className="item_9622">
                    <img src="https://p4.wallpaperbetter.com/wallpaper/747/950/447/sea-landscape-pool-nature-wallpaper-preview.jpg" alt="Image" />
                    <div className="textOnImg_9622">London</div>
                    <div className="item-overlay top" />
                  </div>
                </div>
                <div className="col-md-6">
                  <div className="item_9622">
                    <img src="https://cdn.pixabay.com/photo/2013/10/16/18/43/turtle-196424_960_720.jpg" alt="Image" />
                    <div className="textOnImg_9622">London</div>
                    <div className="item-overlay top" />
                  </div>
                </div>
                <div className="col-md-6">
                  <div className="item_9622">
                    <img src="https://cdn.pixabay.com/photo/2013/11/01/11/13/dolphin-203875_960_720.jpg" alt="Image" />
                    <div className="textOnImg_9622">London</div>
                    <div className="item-overlay top" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default PopularDestinations;
