
import React, { useState } from 'react'
import ImageGallery from './ImageGallery'
import { useNavigate } from 'react-router-dom';
import './Room.css'


function Room() {
    const [times, setTimes] = useState(false);

    const navigate = useNavigate()

    const hotellist = (e) => {
        navigate(`/demo${e}`)
    }


    function viewAll() {
        setTimes(true)
    }
    window.onscroll = function () {
        setTimes(false)
    }
    return (
        <>
            {
                times && (
                    <div >
                        <ImageGallery setTimes={setTimes} />
                    </div>
                )
            }
            <div id='hide' >

                <div className="nav_11622" style={{ marginBottom: "-80px" }}>
                    <ul>
                        <li><a href="#photos">PHOTOS</a></li>
                        <li><a href="#Amenities">HOTEL AMENITIES</a></li>
                        <li><a href="#nearby">NEARBY ATTRACTIONS</a></li>
                    </ul>
                </div>
                <div id='photos'><br />
                    <div className="container" >
                        <div className="imgSec_gallery_11622 mt-5">
                            {/* <div className="row">
                            <div className="col-md-8">
                                <div className="row">
                                    <div className="col-md-8">
                                        <div className='img_gallery'>
                                            <div className='overlayimg_11622'>
                                                <img src="https://images.pexels.com/photos/338504/pexels-photo-338504.jpeg?cs=srgb&dl=pexels-thorsten-technoman-338504.jpg&fm=jpg" alt="loading..." style={{ width: "100%", height: "325px" }} />
                                            </div>
                                        </div>
                                    </div>
                                    <div className="col-md-4">
                                        <div className='img_gallery'>
                                            <div className='overlayimg_11622'>
                                                <img src="https://wallpapershome.com/images/pages/ico_h/6498.jpg" alt="loading..." style={{ width: "160px", height: "160px" }} />
                                            </div>
                                            <div className='overlayimg_11622'>
                                                <img src="https://images.hdqwalls.com/wallpapers/the-cyberpunk-hotel-4k-ef.jpg" alt="loading..." style={{ width: "160px", height: "160px" }} />
                                            </div>
                                            <div className='overlayimg_11622'>
                                                <img src="https://wallpaperaccess.com/full/6688071.jpg" alt="loading..." style={{ width: "160px", height: "160px" }} />
                                            </div>
                                                <div className='overlayimg_11622' onClick={viewAll}>
                                                <img src="https://c4.wallpaperflare.com/wallpaper/624/380/1000/life-resort-hotel-resort-hotel-wallpaper-preview.jpg" alt="loading..." style={{ width: "160px", height: "160px" }} />
                                                <div className="overlay_11622"></div>
                                                <div className="cenertada" >View All</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                            <div className="col-md-4">
                                
                            </div>
                        </div> */}
                            {/* ================================================================================== */}
                            <div className="row" >
                                <div className="col-md-5" style={{cursor: "pointer" }} onClick={viewAll}>
                                    <div className="galleryImage276 mt-2">
                                        <img
                                            src="https://wallpapershome.com/images/pages/ico_h/659.jpg"
                                            alt=""
                                        />
                                    </div>
                                </div>
                                <div className="col-md-4">
                                    <div className="">
                                        <div className="row">
                                            <div className="col-md-6 col-6 mt-2" >
                                                <div className="card_7722" style={{ width: "12rem", cursor:"pointer"  }} onClick={viewAll}>
                                                    <img
                                                        className="card-img-top"
                                                        src="https://wallpaperaccess.com/full/2690549.jpg"
                                                        alt="Card image cap"
                                                    />
                                                </div>
                                            </div>
                                            <div className="col-md-6 col-6 mt-2 ">
                                                <div className="card_7722" style={{ width: "12rem" , cursor:"pointer" }} onClick={viewAll}>
                                                    <img
                                                        className="card-img-top"
                                                        src="https://images.unsplash.com/photo-1561501900-3701fa6a0864?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MXx8bHV4dXJ5JTIwaG90ZWx8ZW58MHx8MHx8&w=1000&q=80"
                                                        alt="Card image cap"
                                                    />
                                                </div>
                                            </div>
                                            <div className="col-md-6 col-6 mt-2">
                                                <div className="card_7722" style={{ width: "12rem", cursor:"pointer" }} onClick={viewAll}>
                                                    <img
                                                        className="card-img-top"
                                                        src="https://ak.picdn.net/shutterstock/videos/6899629/thumb/11.jpg"
                                                        alt="Card image cap"
                                                    />
                                                </div>
                                            </div>
                                            <div className="col-md-6 col-6 mt-2">
                                                <div style={{ width: "12rem" }} className='overlayimg_11622 card_7722' onClick={viewAll}>
                                                    <img
                                                        className="card-img-top"
                                                        src="https://img.freepik.com/free-photo/top-view-roses-flowers_23-2148860041.jpg?w=2000"
                                                        alt="Card image cap"
                                                    />
                                                    <div className="overlay_11622"></div>
                                                    <div className="cenertada" >View All</div>

                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                                <div className="col-md-3 mt-3" style={{ fontSize: "14px" }}>
                                    {/* <div>check In &#8594; Chech out</div> */}
                                    <h5>About Hotel</h5>
                                    
                                    <hr />

                                    <div className="row">
                                        <div className="col-md-6 col-6">
                                            <p>
                                                <i className="fa fa-wifi"></i> Free Wifi
                                            </p>
                                            <p>
                                                <i class="fa-solid fa-bell-concierge"></i> Room Service
                                            </p>
                                            <p>
                                                <i class="fa-solid fa-dumbbell"></i> Gym
                                            </p>
                                        </div>
                                        <div className="col-md-6 col-6">
                                            <p>
                                                <i class="fa fa-cutlery" aria-hidden="true"></i> Restourent
                                            </p>
                                            <p>
                                                <i class="fa fa-parking" aria-hidden="true"></i> Parking
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            {/* ================================================================================== */}
                        </div>
                    </div>
                </div>

                <div style={{ backgroundColor: "#f5f6f8" }}>
                    <div className="container mb-5 mt-5 ">
                        {
                            Array(3).fill().map((i) => (
                                <div className="roomMainSec_11622 mb-3">
                                    <div className="ribbon_11622">Recommended</div>

                                    <div className="row">
                                        <div className="col-md-8">
                                            <div className="room_11622">
                                                <div className="innerSide_11622">
                                                    <h2>TWIN PREMIER </h2>
                                                    <span><i class="fa-solid fa-check"></i> BreakFast</span>
                                                    <div className='bottmSec_11622'>
                                                        <span className='id_11622'>PAN CARD NOT APPLICABLE</span> <span style={{ fontSize: "13px" }}>Essential Info</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>


                                        <div className="col-md-4 col-12" style={{ float: "right" }}>
                                            <div className="room_11622">
                                                <span>Non-Refundable</span> <span className='roomAvl_11622'><img src="https://dhiz4uvf5rpaq.cloudfront.net/in/V2/assets/images/bell.png" alt="" /> 2 Room Left</span><br />
                                                <span style={{ fontSize: "25px", fontWeight: "700", color: "black" }}>₹2,484</span> <span><button className='btn_11622' onClick={() => hotellist('-7777')}><b>Book Now</b></button> </span>
                                            </div>
                                        </div>
                                    </div>



                                </div>
                            ))
                        }

                        {/* 1 section=======================================end */}
                        <div id='Amenities'><br />
                            <div className="aminities_11622 mt-5">
                                <h5 style={{ fontSize: "14px", padding: "15px" }}>Amenities & Info</h5>
                                <div className="facility_11622">
                                    <ul>
                                        <li><i className="fa-solid fa-car"></i>  Parking</li>
                                        <li><i class="fa-solid fa-wifi"></i>  Wifi</li>
                                    </ul>
                                </div>

                                <div>

                                    <h5 style={{ fontSize: "14px", padding: "15px", marginBottom: "-20px" }}>GENERAL</h5>
                                    <div className="row">
                                        <div className="col-md-8">
                                            <div className="row list_11622">
                                                <div className="col-md-4">
                                                    <ul class="list-unstyled  text-small text-left">
                                                        <li class="mb-2">
                                                            <i class="fa fa-check mr-2 text-primary"></i> Lorem ipsum dolor sit amet</li>
                                                        <li class="mb-2">
                                                            <i class="fa fa-check mr-2 text-primary"></i> Sed ut perspiciatis</li>
                                                        <li class="mb-2">
                                                            <i class="fa fa-check mr-2 text-primary"></i> At vero eos et accusamus</li>
                                                        <li class="mb-2">
                                                            <i class="fa fa-check mr-2 text-primary"></i> Lorem ipsum dolor sit amet</li>
                                                        <li class="mb-2">
                                                            <i class="fa fa-check mr-2 text-primary"></i> Sed ut perspiciatis</li>
                                                        <li class="mb-2">
                                                            <i class="fa fa-check mr-2 text-primary"></i> At vero eos et accusamus</li>
                                                    </ul>
                                                </div>
                                                <div className="col-md-4">
                                                    <ul class="list-unstyled  text-small text-left">
                                                        <li class="mb-2">
                                                            <i class="fa fa-check mr-2 text-primary"></i> Lorem ipsum dolor sit amet</li>
                                                        <li class="mb-2">
                                                            <i class="fa fa-check mr-2 text-primary"></i> Sed ut perspiciatis</li>
                                                        <li class="mb-2">
                                                            <i class="fa fa-check mr-2 text-primary"></i> At vero eos et accusamus</li>
                                                        <li class="mb-2">
                                                            <i class="fa fa-check mr-2 text-primary"></i> Lorem ipsum dolor sit amet</li>
                                                        <li class="mb-2">
                                                            <i class="fa fa-check mr-2 text-primary"></i> Sed ut perspiciatis</li>
                                                        <li class="mb-2">
                                                            <i class="fa fa-check mr-2 text-primary"></i> At vero eos et accusamus</li>
                                                    </ul>
                                                </div>
                                                <div className="col-md-4">
                                                    <ul class="list-unstyled  text-small text-left">
                                                        <li class="mb-2">
                                                            <i class="fa fa-check mr-2 text-primary"></i> Lorem ipsum dolor sit amet</li>
                                                        <li class="mb-2">
                                                            <i class="fa fa-check mr-2 text-primary"></i> Sed ut perspiciatis</li>
                                                        <li class="mb-2">
                                                            <i class="fa fa-check mr-2 text-primary"></i> At vero eos et accusamus</li>
                                                        <li class="mb-2">
                                                            <i class="fa fa-check mr-2 text-primary"></i> Lorem ipsum dolor sit amet</li>
                                                        <li class="mb-2">
                                                            <i class="fa fa-check mr-2 text-primary"></i> Sed ut perspiciatis</li>
                                                        <li class="mb-2">
                                                            <i class="fa fa-check mr-2 text-primary"></i> At vero eos et accusamus</li>
                                                    </ul>
                                                </div>
                                            </div>



                                            <div className='hotelFaciliti_11622'>
                                                <h5>PARKING</h5>
                                                <div className="row">
                                                    <div className="col-md-4">
                                                        <ul class="list-unstyled  text-small text-left">
                                                            <li class="mb-2">
                                                                <i class="fa fa-check mr-2 text-primary"></i> Free valet parking</li>
                                                        </ul>
                                                    </div>
                                                    <div className="col-md-4">
                                                        <ul class="list-unstyled  text-small text-left">
                                                            <li class="mb-2">
                                                                <i class="fa fa-check mr-2 text-primary"></i> Wheelchair accessible parking</li>
                                                        </ul>
                                                    </div>
                                                    <div className="col-md-4"></div>
                                                </div>
                                            </div>

                                            <div className='hotelFaciliti_11622'>
                                                <h5>LOUNGE</h5>
                                                <div className="row">
                                                    <div className="col-md-4">
                                                        <ul class="list-unstyled  text-small text-left">
                                                            <li class="mb-2">
                                                                <i class="fa fa-check mr-2 text-primary"></i> Lorem ipsum dolor sit amet</li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>

                                            <div className='hotelFaciliti_11622'>
                                                <h5>DISABLE FRIENDLY</h5>
                                                <div className="row">
                                                    <div className="col-md-4">
                                                        <ul class="list-unstyled  text-small text-left">
                                                            <li class="mb-2">
                                                                <i class="fa fa-check mr-2 text-primary"></i> Wheelchair-accessible lounge</li>
                                                        </ul>
                                                    </div>
                                                    <div className="col-md-4">
                                                        <ul class="list-unstyled  text-small text-left">
                                                            <li class="mb-2">
                                                                <i class="fa fa-check mr-2 text-primary"></i> Lorem ipsum dolor sit amet</li>
                                                        </ul>
                                                    </div>
                                                    <div className="col-md-4"></div>
                                                </div>
                                            </div>

                                            <div className='hotelFaciliti_11622'>
                                                <h5>BREAKFAST</h5>
                                                <div className="row">
                                                    <div className="col-md-4">
                                                        <ul class="list-unstyled  text-small text-left">
                                                            <li class="mb-2">
                                                                <i class="fa fa-check mr-2 text-primary"></i> Lorem ipsum dolor sit amet</li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>

                                            <div className='hotelFaciliti_11622'>
                                                <h5>BUSINESS CENTER</h5>
                                                <div className="row">
                                                    <div className="col-md-4">
                                                        <ul class="list-unstyled  text-small text-left">
                                                            <li class="mb-2">
                                                                <i class="fa fa-check mr-2 text-primary"></i> Lorem ipsum dolor sit amet</li>
                                                            <li class="mb-2">
                                                                <i class="fa fa-check mr-2 text-primary"></i> Lorem ipsum dolor sit amet</li>
                                                        </ul>
                                                    </div>

                                                    <div className="col-md-4">
                                                        <ul class="list-unstyled  text-small text-left">
                                                            <li class="mb-2">
                                                                <i class="fa fa-check mr-2 text-primary"></i> Lorem ipsum dolor sit amet</li>
                                                            <li class="mb-2">
                                                                <i class="fa fa-check mr-2 text-primary"></i> Lorem ipsum dolor sit amet</li>
                                                        </ul>
                                                    </div>

                                                    <div className="col-md-4">
                                                        <ul class="list-unstyled  text-small text-left">
                                                            <li class="mb-2">
                                                                <i class="fa fa-check mr-2 text-primary"></i> Lorem ipsum dolor sit amet</li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>

                                            <div className='hotelFaciliti_11622'>
                                                <h5>BAR</h5>
                                                <div className="row">
                                                    <div className="col-md-4">
                                                        <ul class="list-unstyled  text-small text-left">
                                                            <li class="mb-2">
                                                                <i class="fa fa-check mr-2 text-primary"></i> Lorem ipsum dolor sit amet</li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>

                                            <div className='hotelFaciliti_11622'>
                                                <h5>SPA</h5>
                                                <div className="row">
                                                    <div className="col-md-4">
                                                        <ul class="list-unstyled  text-small text-left">
                                                            <li class="mb-2">
                                                                <i class="fa fa-check mr-2 text-primary"></i> Lorem ipsum dolor sit amet</li>
                                                            <li class="mb-2">
                                                                <i class="fa fa-check mr-2 text-primary"></i> Lorem ipsum dolor sit amet</li>
                                                        </ul>
                                                    </div>
                                                    <div className="col-md-4">
                                                        <ul class="list-unstyled  text-small text-left">
                                                            <li class="mb-2">
                                                                <i class="fa fa-check mr-2 text-primary"></i> Lorem ipsum dolor sit amet</li>
                                                            <li class="mb-2">
                                                                <i class="fa fa-check mr-2 text-primary"></i> Lorem ipsum dolor sit amet</li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>

                                            <div className='hotelFaciliti_11622'>
                                                <h5>LAUNDRY SERVICES</h5>
                                                <div className="row">
                                                    <div className="col-md-4">
                                                        <ul class="list-unstyled  text-small text-left">
                                                            <li class="mb-2">
                                                                <i class="fa fa-check mr-2 text-primary"></i> Lorem ipsum dolor sit amet</li>
                                                        </ul>
                                                    </div>
                                                    <div className="col-md-4">
                                                        <ul class="list-unstyled  text-small text-left">
                                                            <li class="mb-2">
                                                                <i class="fa fa-check mr-2 text-primary"></i> Lorem ipsum dolor sit amet</li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>

                                            <div className='about_11622'>
                                                <h5>ABOUT HOTEL</h5>
                                                <p>Pamper yourself with a visit to the spa, which offers massages, body treatments, and facials. You can take advantage of recreational amenities such as a health club, an outdoor pool, and a spa tub. Additional features at this hotel include wireless Internet access (surcharge), concierge services, and gift shops/newsstands.Grab a bite at Citrus, one of the hotel's 4 restaurants, or stay in and take advantage of the 24-hour room service. Snacks are also available at the coffee shop/cafe. Mingle with other guests at the complimentary reception, held daily. Unwind at the end of the day with a drink at the bar/lounge or the poolside bar. Buffet breakfasts are available for a fee.Featured amenities include wired Internet access (surcharge), a 24-hour business center, and limo/town car service. Planning an event in Mumbai? This hotel has 11743 square feet (1091 square meters) of space consisting of conference space and a meeting room. For a surcharge, guests may use a roundtrip airport shutt</p>
                                            </div>


                                        </div>


                                        <div className="col-md-4">
                                            <div className='mb-2 rightSideImg_11622'>
                                                <img src="https://p4.wallpaperbetter.com/wallpaper/858/551/637/hotel-terrace-chairs-ocean-maldives-hd-wallpaper-2560%C3%971440-wallpaper-preview.jpg" alt="" style={{ width: "100%" }} />
                                            </div>
                                            <div className='mb-2 rightSideImg_11622'>
                                                <img src="https://c4.wallpaperflare.com/wallpaper/451/186/556/best-hotels-booking-pool-vacation-wallpaper-preview.jpg" alt="" style={{ width: "100%" }} />
                                            </div>
                                            <div className='mb-2 rightSideImg_11622'>
                                                <img src="https://besthqwallpapers.com/Uploads/6-11-2017/27286/thumb2-interior-of-hotel-room-modern-design-brown-tone-hotel-room-room-for-three.jpg" alt="" style={{ width: "100%" }} />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>



                    <div id='nearby'><br /><br /><br />
                        <div className="container nearby_11622">
                            <div><h5>Nearby Attractions</h5></div>
                            <hr />
                            <div className="row">
                                <div className="col-md-3">
                                    <li>Ayani Mega Mall (0.3 km)</li>
                                    <li>Ayani Mega Mall (0.3 km)</li>
                                    <li>Ayani Mega Mall (0.3 km)</li>
                                    <li>Ayani Mega Mall (0.3 km)</li>

                                </div>
                                <div className="col-md-3">
                                    <li>Ayani Mega Mall (0.3 km)</li>
                                    <li>Ayani Mega Mall (0.3 km)</li>
                                    <li>Ayani Mega Mall (0.3 km)</li>
                                    <li>Ayani Mega Mall (0.3 km)</li>

                                </div>
                                <div className="col-md-3">
                                    <li>Ayani Mega Mall (0.3 km)</li>
                                    <li>Ayani Mega Mall (0.3 km)</li>
                                    <li>Ayani Mega Mall (0.3 km)</li>
                                    <li>Ayani Mega Mall (0.3 km)</li>

                                </div>
                                <div className="col-md-3">
                                    <li>Ayani Mega Mall (0.3 km)</li>
                                    <li>Ayani Mega Mall (0.3 km)</li>
                                    <li>Ayani Mega Mall (0.3 km)</li>
                                    <li>Ayani Mega Mall (0.3 km)</li>

                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </>
    )
}

export default Room