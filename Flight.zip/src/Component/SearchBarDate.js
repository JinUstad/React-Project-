import React, { useState } from 'react';
import DatePicker from 'react-date-picker';
import './SearchBar.css'

function SearchBarDate() {
    const [value, onChange] = useState(new Date());
  return (
      <>
          <div className='datapicker_7622'>
              <DatePicker onChange={onChange} value={value} yearPlaceholder={"yyyy"} format={"dd-MM-y"} monthPlaceholder={"mm"} dayPlaceholder={"dd"} />
          </div>
      </>
  )
}

export default SearchBarDate