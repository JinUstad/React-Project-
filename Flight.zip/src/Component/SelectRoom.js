import React from 'react'
import './SelectRoom.css'
import { useNavigate } from 'react-router-dom'
import SearchBar from './SearchBar'
import FlightBookingHeader from './FlightBookingHeader'


function SelectRoom() {



    const navigate = useNavigate()

    const selectRoom = (e) => {
        navigate(`/room${e}`)
    }

    return (
        <>
            {/* new start */}
            <div className="mainSecBooking_13622">
                <div className="container selectRoom_14622 mt-1">
                    <div className="row justify-content-center" style={{ marginTop: "auto" }}>
                        <div className="col-md-2 col-6 flightdetSec_25622">
                            <div className="cardstyle11_22622" style={{ display: "flex", flexDirection: "row" }}>
                                <div style={{ width: "30%", display: "grid" }}>
                                    <img src="https://c0.wallpaperflare.com/preview/754/862/416/4k-wallpaper-architecture-buildings-city.jpg" style={{ margin: "auto", height: "30px", width: "30px" }} />
                                </div>
                                <div style={{ width: "70%", display: "grid" }}>
                                    <section className="flightDet_22622" style={{ margin: "auto", width: "100%", marginTop: "20px" }}>
                                        {/* <span>IndiGo</span> */}
                                        <p>₹ 9132</p>
                                    </section>
                                </div>
                            </div>
                        </div>
                        {/*  */}
                        <div className="col-md-2 col-6 flightdetSec_25622">
                            <div style={{ display: "flex", flexDirection: "row", width: "100%", display: "grid" }}>
                                <section className="flightDet_23622" style={{ marginTop: "5px", width: "100%" }} type="button" data-toggle="modal" data-target=".bd-example-modal-lg">
                                    <span>Check-In</span>
                                    <p>27 Jun’22 , Monday</p>
                                </section>
                            </div>
                        </div>

                        <div className="col-md-2 col-6 flightdetSec_25622">
                            <div style={{ display: "flex", flexDirection: "row", width: "100%", display: "grid" }}>
                                <section className="flightDet_23622" style={{ margin: "auto", width: "100%", marginTop: "20px" }}>
                                    {/* <span>Check-In</span> */}
                                    <p>27 Jun’22 , Monday</p>
                                </section>
                            </div>
                        </div>


                        <div className="col-md-2 col-6 flightdetSec_25622">
                            <div style={{ display: "flex", flexDirection: "row", width: "100%", display: "grid" }}>
                                <section className="flightDet_23622" style={{ marginTop: "5px", width: "100%" }}>
                                    <span>Check-Out</span>
                                    <p>28 Jun’22 , Tuesday</p>
                                </section>
                            </div>
                        </div>

                        <div className="col-md-2 col-6 flightdetSec_25622">
                            <div style={{ display: "flex", flexDirection: "row", width: "100%", display: "grid" }}>
                                <section className="flightDet_23622" style={{ marginTop: "5px", width: "100%" }}>
                                    <span>Rooms & Guests</span>
                                    <p>1 Room 1 Guest</p>
                                </section>
                            </div>
                        </div>

                        <div className="col-md-2 col-6 flightdetSec_25622">
                            <div style={{ display: "flex", flexDirection: "row", width: "100%", display: "grid" }}>
                                <section className="flightDet_23622" style={{ marginTop: "5px", width: "100%" }}>
                                    <div className='searchSec_22622'>
                                        <span><i class="fa-solid fa-share-nodes"></i></span><span className='search_25622'>MORE SEARCH</span>
                                    </div>
                                </section>
                            </div>
                        </div>
                        {/*  */}
                    </div>
                </div>

                <div className="container ">
                    <div className="row" style={{ marginBottom: "-38px" }}>
                        <div className="col-md-4">
                            <div className="map_14622">
                                <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d28002.973975280885!2d77.50053334520346!3d28.67852432472643!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sen!2sin!4v1655198478651!5m2!1sen!2sin" allowFullScreen loading="lazy" referrerPolicy="no-referrer-when-downgrade" />
                            </div>
                        </div>
                        <div className="col-md-8">
                            <div className="showing_14622">
                                <p>Showing 44 of 44 hotels found</p>
                            </div>
                            <div className="filterSec_14622">
                                <div className="row">
                                    <div className="col-md-2 col-2" style={{ backgroundColor: "#f5f6f8" }}>
                                        <div className="sort_14622" >
                                            <p>SHORT BY</p>
                                        </div>
                                    </div>
                                    <div className="col-md-3 col-3">
                                        <div className="filterLink_14622">
                                            <p>DISTANCE FROM CITY CENTRE</p>
                                        </div>
                                    </div>
                                    <div className="col-md-3 col-3">
                                        <div className="filterLink_14622">
                                            <p>FEATURED &darr;</p>
                                        </div>
                                    </div>
                                    <div className="col-md-2 col-2">
                                        <div className="filterLink_14622">
                                            <p>RATING</p>
                                        </div>
                                    </div>
                                    <div className="col-md-2 col-2">
                                        <div className="filterLink_14622">
                                            <p>PRICE</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                {/* new end */}
                <div className="container mt-5">
                    <div className="row">
                        <div className="col-md-4">
                            <div className="filterList_13622" >
                                <details class="details-comp" open>
                                    <summary class="summary-colapse">
                                        STAR RATING
                                    </summary>
                                    <div>
                                        <ul>
                                            <input type="checkbox" className='inputs_13622' />{Array(3).fill().map((i) => (<i class="fa-solid fa-star" style={{ color: "#ffb500", fontSize: "14px", margin: "1px" }}></i>))}<br />
                                            <input type="checkbox" className='inputs_13622' />{Array(2).fill().map((i) => (<i class="fa-solid fa-star" style={{ color: "#ffb500", fontSize: "14px", margin: "1px" }}></i>))}<br />
                                            <input type="checkbox" className='inputs_13622' />{Array(1).fill().map((i) => (<i class="fa-solid fa-star" style={{ color: "#ffb500", fontSize: "14px", margin: "1px" }}></i>))}<br />
                                        </ul>
                                    </div>
                                </details>
                                <details class="details-comp" open>
                                    <summary class="summary-colapse">
                                        PRICE RANGE
                                    </summary>
                                    <div>
                                        <ul>
                                            <div className='lable_14622'>
                                                <input type="checkbox" className='inputs_13622' />
                                                <label htmlFor="vehicle2"> ₹ 3000 to ₹ 9000</label><br />
                                                <input type="checkbox" className='inputs_13622' />
                                                <label htmlFor="vehicle2"> ₹ 7000 to ₹ 12000</label><br />
                                                <input type="checkbox" className='inputs_13622' />
                                                <label htmlFor="vehicle2"> ₹ 5000 to ₹ 10000</label><br />

                                            </div>

                                        </ul>
                                    </div>

                                </details>
                                <details class="details-comp" open>
                                    <summary class="summary-colapse">
                                        DEALS
                                    </summary>
                                    <div>
                                        <ul>
                                            <div className='lable_14622'>
                                                <input type="checkbox" className='inputs_13622' />
                                                <label htmlFor="vehicle2"> Exclusive deals Only</label><br />
                                            </div>

                                        </ul>
                                    </div>

                                </details>
                                <details class="details-comp" open >
                                    <summary class="summary-colapse" >
                                        AMENITIES
                                    </summary>
                                    <div >
                                        <ul >
                                            <div className='lable_14622'>
                                                <input type="checkbox" className='inputs_13622' />
                                                <label htmlFor="vehicle2"> Parking</label><br />
                                                <input type="checkbox" className='inputs_13622' />
                                                <label htmlFor="vehicle2"> Currency Exchange</label><br />
                                                <input type="checkbox" className='inputs_13622' />
                                                <label htmlFor="vehicle2"> Spa</label><br />
                                                <a href="">View All</a>
                                            </div>
                                        </ul>
                                    </div>
                                </details>
                            </div>
                        </div>

                        <div className="col-md-8">

                            <div className="border_13622 mb-3">
                                <div className="row">
                                    <div className="col-md-3">
                                        <div className='hotelImg_13622'>
                                            <img src="https://images.wallpaperscraft.com/image/single/burj_al_arab_hotel_dubai_uae_sky_sea_59061_3840x2160.jpg" alt="" style={{ width: "100%" }} />
                                            <div className="overlay_13622"></div>
                                        </div>
                                    </div>
                                    <div className="col-md-6">
                                        <span className="selectHotel_13622"> Garuda Hotel Pontianak</span>{Array(3).fill().map((i) => (<span className='icon_13622'> <i class="fa-solid fa-star"></i></span>))}
                                        <div className='desc_13622'>
                                            <a href=""><i class="fa-solid fa-location-dot"></i>&nbsp;location</a>
                                            <address>194.6 km From (City Centre)</address>
                                            <span className='span3_1622'><i class="fa-solid fa-mug-hot"></i> Free breakfast</span>&nbsp;<span className='span3_1622'><i class="fa-solid fa-mug-hot"></i> Lunch</span>
                                        </div>
                                    </div>
                                    <div className="col-md-3">
                                        <div className='rate_13622'>
                                            <p>₹ 1,641</p>
                                            <span>+ ₹ 246 Taxes</span><br />
                                            <button className='btnbtn_13622' onClick={() => selectRoom('12345')}>Select Room</button><br />
                                            <span className='shortList_13622'> Shortlist</span>

                                        </div>
                                    </div>
                                </div>

                            </div>
                            {/* -========== */}
                            <div className="border_13622 mb-3">
                                <div className="row">
                                    <div className="col-md-3">
                                        <div className='hotelImg_13622'>
                                            <img src="https://besthqwallpapers.com/Uploads/27-12-2017/35365/thumb2-baraza-resort-and-spa-4k-hotel-zanzibar-hdr.jpg" alt="" style={{ width: "100%" }} />
                                            <div className="overlay_13622"></div>
                                        </div>
                                    </div>
                                    <div className="col-md-6">
                                        <span className="selectHotel_13622"> Garuda Hotel Pontianak</span>{Array(3).fill().map((i) => (<span className='icon_13622'> <i class="fa-solid fa-star"></i></span>))}
                                        <div className='desc_13622'>
                                            <a href=""><i class="fa-solid fa-location-dot"></i>&nbsp;location</a>
                                            <address>194.6 km From (City Centre)</address>
                                            <span className='span3_1622'><i class="fa-solid fa-mug-hot"></i> Free breakfast</span>&nbsp;<span className='span3_1622'><i class="fa-solid fa-mug-hot"></i> Lunch</span>
                                        </div>
                                    </div>
                                    <div className="col-md-3">
                                        <div className='rate_13622'>
                                            <p>₹ 1,641</p>
                                            <span>+ ₹ 246 Taxes</span><br />
                                            <button className='btnbtn_13622' onClick={() => selectRoom('12345')}>Select Room</button><br />
                                            <span className='shortList_13622'> Shortlist</span>

                                        </div>
                                    </div>
                                </div>

                            </div>
                            {/* ================= */}
                            <div className="border_13622 mb-3">
                                <div className="row">
                                    <div className="col-md-3">
                                        <div className='hotelImg_13622'>
                                            <img src="https://images.unsplash.com/photo-1561501900-3701fa6a0864?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MXx8bHV4dXJ5JTIwaG90ZWx8ZW58MHx8MHx8&w=1000&q=80" alt="" style={{ width: "100%" }} />
                                            <div className="overlay_13622"></div>
                                        </div>
                                    </div>
                                    <div className="col-md-6">
                                        <span className="selectHotel_13622"> Garuda Hotel Pontianak</span>{Array(3).fill().map((i) => (<span className='icon_13622'> <i class="fa-solid fa-star"></i></span>))}
                                        <div className='desc_13622'>
                                            <a href=""><i class="fa-solid fa-location-dot"></i>&nbsp;location</a>
                                            <address>194.6 km From (City Centre)</address>
                                            <span className='span3_1622'><i class="fa-solid fa-mug-hot"></i> Free breakfast</span>&nbsp;<span className='span3_1622'><i class="fa-solid fa-mug-hot"></i> Lunch</span>
                                        </div>
                                    </div>
                                    <div className="col-md-3">
                                        <div className='rate_13622'>
                                            <p>₹ 1,641</p>
                                            <span>+ ₹ 246 Taxes</span><br />
                                            <button className='btnbtn_13622' onClick={() => selectRoom('12345')}>Select Room</button><br />
                                            <span className='shortList_13622'> Shortlist</span>

                                        </div>
                                    </div>
                                </div>

                            </div>
                            {/* ======================= */}

                        </div>
                    </div>
                </div>
            </div>


            {/* <SearchBar/> */}
            <div>
 

                {/* Large modal */}
                {/* <button type="button" className="btn btn-primary" data-toggle="modal" data-target=".bd-example-modal-lg">Large modal</button> */}
                <div className="modal fade bd-example-modal-lg p-0" tabIndex={-1} role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" >
                    <div className="" style={{ width: "100%"}}>
                        <div className="modal-content" style={{ marginTop: "200px"}} >
                            <FlightBookingHeader />
                        </div>
                    </div>
                </div>
                
            </div>

        </>
    )
}

export default SelectRoom