import React from 'react'
import './SideDetails.css'
function SideDetails() {
  return (
    <>
   
      <div className="Side_Details_97">
        <div className="wrapperDetails97">
                <h6>Quick Filter</h6>
                <input type="checkbox" class="defaultCheckbox" /> <span style={{fontSize:'14px'}}>myDeal upto 7% off</span> <span style={{float:'right' , color:'#9b9b9b' , fontSize:'13px'}}>(09)</span> <br />
                <input type="checkbox" class="defaultCheckbox" /> <span style={{fontSize:'14px'}}>Sleeper</span> <span style={{float:'right' , color:'#9b9b9b' , fontSize:'13px'}}>(20)</span> <br />
                <input type="checkbox" class="defaultCheckbox" /> <span style={{fontSize:'14px'}}>AC</span> <span style={{float:'right' , color:'#9b9b9b' , fontSize:'13px'}}>(10)</span> <br />
                <input type="checkbox" class="defaultCheckbox" /> <span style={{fontSize:'14px'}}>Pickup after 6pm</span> <span style={{float:'right' , color:'#9b9b9b' , fontSize:'13px'}}>(36)</span>
                <hr />
        </div>
        <div className="wrapperDetails971">
                <h6>Deal & Offers</h6>
                <input type="checkbox" class="defaultCheckbox" /> <span style={{fontSize:'14px'}}>myDeal upto 7% off</span> <span style={{float:'right' , color:'#9b9b9b' , fontSize:'13px'}}>(09)</span> <br />
                <input type="checkbox" class="defaultCheckbox" /> <span style={{fontSize:'14px'}}>Sleeper</span> <span style={{float:'right' , color:'#9b9b9b' , fontSize:'13px'}}>(20)</span> <br />
                <hr />
        </div>
        <div className="wrapperDetails972">
                <h6>Free Cancellection</h6>
                <input type="checkbox" class="defaultCheckbox" /> <span style={{fontSize:'14px'}}>myDeal upto 7% off</span> <span style={{float:'right' , color:'#9b9b9b' , fontSize:'13px'}}>(09)</span> <br />
                <input type="checkbox" class="defaultCheckbo" /> <span style={{fontSize:'14px'}}>Sleeper</span> <span style={{float:'right' , color:'#9b9b9b' , fontSize:'13px'}}>(20)</span> <br />
                <hr />
        </div>
        <div className="wrapperDetails973">
                <h6>Safety Feature</h6>
                <hr />
        </div>
        <div className="wrapperDetails974">
                <h6>Boarding Points</h6>
                <input type="text" placeholder='Enter Boarding Point' className='w-100'/>
                <input type="checkbox" class="defaultCheckbox" /> <span style={{fontSize:'14px'}}>myDeal upto 7% off</span> <span style={{float:'right' , color:'#9b9b9b' , fontSize:'13px'}}>(09)</span> <br />
                <input type="checkbox" class="defaultCheckbox" /> <span style={{fontSize:'14px'}}>myDeal upto 7% off</span> <span style={{float:'right' , color:'#9b9b9b' , fontSize:'13px'}}>(09)</span> <br />
                <input type="checkbox" class="defaultCheckbox" /> <span style={{fontSize:'14px'}}>myDeal upto 7% off</span> <span style={{float:'right' , color:'#9b9b9b' , fontSize:'13px'}}>(09)</span> <br />
                <input type="checkbox" class="defaultCheckbox" /> <span style={{fontSize:'14px'}}>myDeal upto 7% off</span> <span style={{float:'right' , color:'#9b9b9b' , fontSize:'13px'}}>(09)</span> <br />
                <hr />
        </div>
        <div className="pickTime97">
          <div className="row">
            {
              Array(4).fill().map(()=>(
                <>
                <div className="col-md-6 col-6">
                  <div className="pickTimeCard97">
                    <i className='fa fa-sun'></i>
                    <h6>morning(0)</h6>
                    <p>6pm to 11pm</p>
                  </div>
                </div>
                </> 
              ))
            }
            
          </div>
        <hr />
        </div>
        <div className="wrapperDetails974">
                <h6>Bus Types</h6>
                <input type="checkbox" class="defaultCheckbox" /> <span style={{fontSize:'14px'}}>myDeal upto 7% off</span> <span style={{float:'right' , color:'#9b9b9b' , fontSize:'13px'}}>(09)</span> <br />
                <input type="checkbox" class="defaultCheckbox" /> <span style={{fontSize:'14px'}}>myDeal upto 7% off</span> <span style={{float:'right' , color:'#9b9b9b' , fontSize:'13px'}}>(09)</span> <br />
                <input type="checkbox" class="defaultCheckbox" /> <span style={{fontSize:'14px'}}>myDeal upto 7% off</span> <span style={{float:'right' , color:'#9b9b9b' , fontSize:'13px'}}>(09)</span> <br />
                <input type="checkbox" class="defaultCheckbox" /> <span style={{fontSize:'14px'}}>myDeal upto 7% off</span> <span style={{float:'right' , color:'#9b9b9b' , fontSize:'13px'}}>(09)</span> <br />
                <hr />
        </div>
      </div>
    </>
  )
}

export default SideDetails