export default function tabUtil(event, tabName, tab, btn, activeClass) {
  
    for (var i = 0; i < tab.length; i++) {
        tab[i].style.display = "none";
    }
    
    for (var j = 0; j < btn.length; j++) {
        btn[j].className = btn[j].className.replace(` ${activeClass}`, "");
    }
    document.getElementById(tabName).style.display = "block";
    event.currentTarget.classList += ` ${activeClass}`;
}


export function convertTime(minutes){
 var h = Math.floor(minutes / 60);
  var m = minutes % 60;
  h = h < 10 ? '0' + h : h; 
  m = m < 10 ? '0' + m : m; 
  return h + ':' + m;
}





