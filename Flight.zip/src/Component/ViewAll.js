import React, { useEffect } from "react";
import './ViewAll.css'
import LazyLoad from 'react-lazy-load';
function ViewAll() {


  useEffect(() => {
    document.getElementById("bydefault").click();
  }, [])

  function checkhotel(event, tabName) {
    var tab, btn;
    tab = document.getElementsByClassName("checkHotelOffer")
    btn = document.getElementsByClassName("hotelOffer_18622")

    for (var i = 0; i < tab.length; i++) {
      tab[i].style.display = "none";
    }
    for (var j = 0; j < btn.length; j++) {
      btn[j].className = btn[j].className.replace(" active_18622", "")
    }
    document.getElementById(tabName).style.display = "block";
    event.currentTarget.classList += " active_18622";
  }
  return (
    <>
      <div style={{ backgroundColor: "#f6f4f5" }}>
        <div className="container ">
          <h5 style={{ color: "#3c8dc5" }}>Flight Booking Offers for June | Travel Offers on Akbar Travels</h5>
          <div className="selectHotelOffer_18622 my-2" >
            <li className="hotelOffer_18622" onClick={(event) => checkhotel(event, "one")} id='bydefault'><i class="fa-solid fa-grip-lines"></i>  All</li>
            <li className="hotelOffer_18622" onClick={(event) => checkhotel(event, "two")}><i class="fa-solid fa-plane"></i>  Flight</li>
            <li className="hotelOffer_18622" onClick={(event) => checkhotel(event, "three")}><i class="fa-solid fa-hotel"></i>  Hotel</li>
            <li className="hotelOffer_18622" onClick={(event) => checkhotel(event, "four")}><i class="fa-solid fa-tag"></i>  Other</li>
          </div>
          {/* 1 */}
          <div className="checkHotelOffer" id="one">
            <div className="row">
              <div className="col-md-3 mt-2 mb-3  ">
                <LazyLoad height={290} offsetVertical={5}>
                  <div className="card" >
                    <img className="card-img-top" src="https://c4.wallpaperflare.com/wallpaper/577/1005/290/airplane-airplanes-planes-4k-wallpaper-preview.jpg" alt="Card image cap" />
                    <div className="cardBody_18622 text-center">
                      <p className="card-text">Ready to take off with Indigo?</p>
                      <hr />
                      <p><i className="fa fa-clock"></i> Expires 1 month 2 week</p>
                      <button className="btn btn-light w-100">Know More</button>
                    </div>
                  </div>
                </LazyLoad>
              </div>
              <div className="col-md-3 mt-2 mb-3  ">
                <LazyLoad height={290} offsetVertical={5}>
                  <div className="card" >
                    <img className="card-img-top" src="https://wallpaperaccess.com/full/254381.jpg" alt="Card image cap" />
                    <div className="cardBody_18622 text-center">
                      <p className="card-text">Ready to take off with Indigo?</p>
                      <hr />
                      <p><i className="fa fa-clock"></i> Expires 1 month 2 week</p>
                      <button className="btn btn-light w-100">Know More</button>
                    </div>
                  </div>
                </LazyLoad>
              </div>
              <div className="col-md-3 mt-2 mb-3  ">
                <LazyLoad height={290} offsetVertical={5}>
                  <div className="card" >
                    <img className="card-img-top" src="https://wallpapercave.com/wp/wp2574287.jpg" alt="Card image cap" />
                    <div className="cardBody_18622 text-center">
                      <p className="card-text">Ready to take off with Indigo?</p>
                      <hr />
                      <p><i className="fa fa-clock"></i> Expires 1 month 2 week</p>
                      <button className="btn btn-light w-100">Know More</button>
                    </div>
                  </div>
                </LazyLoad>
              </div>
              <div className="col-md-3 mt-2 mb-3  ">
                <LazyLoad height={290} offsetVertical={5}>
                  <div className="card" >
                    <img className="card-img-top" src="https://img.freepik.com/premium-photo/commercial-plane-flying-clouds-4k-image-fast-travel-transport-concept_264404-376.jpg?w=2000" alt="Card image cap" />
                    <div className="cardBody_18622 text-center">
                      <p className="card-text">Ready to take off with Indigo?</p>
                      <hr />
                      <p><i className="fa fa-clock"></i> Expires 1 month 2 week</p>
                      <button className="btn btn-light w-100">Know More</button>
                    </div>
                  </div>
                </LazyLoad>
              </div>
              <div className="col-md-3 mt-2 mb-3  ">
                <LazyLoad height={290} offsetVertical={5}>
                  <div className="card" >
                    <img className="card-img-top" src="https://cdn.wallpapersafari.com/23/77/mRIH8j.jpg" alt="Card image cap" />
                    <div className="cardBody_18622 text-center">
                      <p className="card-text">Ready to take off with Indigo?</p>
                      <hr />
                      <p><i className="fa fa-clock"></i> Expires 1 month 2 week</p>
                      <button className="btn btn-light w-100">Know More</button>
                    </div>
                  </div>
                </LazyLoad>
              </div>
              <div className="col-md-3 mt-2 mb-3  ">
                <LazyLoad height={290} offsetVertical={5}>
                  <div className="card" >
                    <img className="card-img-top" src="https://c4.wallpaperflare.com/wallpaper/775/20/44/landscape-night-airplane-lights-wallpaper-preview.jpg" alt="Card image cap" />
                    <div className="cardBody_18622 text-center">
                      <p className="card-text">Ready to take off with Indigo?</p>
                      <hr />
                      <p><i className="fa fa-clock"></i> Expires 1 month 2 week</p>
                      <button className="btn btn-light w-100">Know More</button>
                    </div>
                  </div>
                </LazyLoad>
              </div>
              <div className="col-md-3 mt-2 mb-3  ">
                <LazyLoad height={290} offsetVertical={5}>
                  <div className="card" >
                    <img className="card-img-top" src="https://www.teahub.io/photos/full/47-473124_airplane-wallpaper-4k.jpg" alt="Card image cap" />
                    <div className="cardBody_18622 text-center">
                      <p className="card-text">Ready to take off with Indigo?</p>
                      <hr />
                      <p><i className="fa fa-clock"></i> Expires 1 month 2 week</p>
                      <button className="btn btn-light w-100">Know More</button>
                    </div>
                  </div>
                </LazyLoad>
              </div>
              <div className="col-md-3 mt-2 mb-3  ">
                <LazyLoad height={290} offsetVertical={5}>
                  <div className="card" >
                    <img className="card-img-top" src="https://c4.wallpaperflare.com/wallpaper/577/1005/290/airplane-airplanes-planes-4k-wallpaper-preview.jpg" alt="Card image cap" />
                    <div className="cardBody_18622 text-center">
                      <p className="card-text">Ready to take off with Indigo?</p>
                      <hr />
                      <p><i className="fa fa-clock"></i> Expires 1 month 2 week</p>
                      <button className="btn btn-light w-100">Know More</button>
                    </div>
                  </div>
                </LazyLoad>
              </div>
              <div className="col-md-3 mt-2 mb-3  ">
                <LazyLoad height={290} offsetVertical={5}>
                  <div className="card" >
                    <img className="card-img-top" src="https://c4.wallpaperflare.com/wallpaper/577/1005/290/airplane-airplanes-planes-4k-wallpaper-preview.jpg" alt="Card image cap" />
                    <div className="cardBody_18622 text-center">
                      <p className="card-text">Ready to take off with Indigo?</p>
                      <hr />
                      <p><i className="fa fa-clock"></i> Expires 1 month 2 week</p>
                      <button className="btn btn-light w-100">Know More</button>
                    </div>
                  </div>
                </LazyLoad>
              </div>
              <div className="col-md-3 mt-2 mb-3  ">
                <LazyLoad height={290} offsetVertical={5}>
                  <div className="card" >
                    <img className="card-img-top" src="https://www.pixelstalk.net/wp-content/uploads/images5/4K-Plane-Wallpaper-Free-Download.jpg" alt="Card image cap" />
                    <div className="cardBody_18622 text-center">
                      <p className="card-text">Ready to take off with Indigo?</p>
                      <hr />
                      <p><i className="fa fa-clock"></i> Expires 1 month 2 week</p>
                      <button className="btn btn-light w-100">Know More</button>
                    </div>
                  </div>
                </LazyLoad>
              </div>
              <div className="col-md-3 mt-2 mb-3  ">
                <LazyLoad height={290} offsetVertical={5}>
                  <div className="card" >
                    <img className="card-img-top" src="https://www.wallpapersshare.com/img/big/airbus-airplane-4k-ultra-hd-wallpaper.jpg" alt="Card image cap" />
                    <div className="cardBody_18622 text-center">
                      <p className="card-text">Ready to take off with Indigo?</p>
                      <hr />
                      <p><i className="fa fa-clock"></i> Expires 1 month 2 week</p>
                      <button className="btn btn-light w-100">Know More</button>
                    </div>
                  </div>
                </LazyLoad>
              </div>
              <div className="col-md-3 mt-2 mb-3  ">
                <LazyLoad height={290} offsetVertical={5}>
                  <div className="card" >
                    <img className="card-img-top" src="https://wallpapershome.com/images/pages/ico_h/6498.jpg" alt="Card image cap" />
                    <div className="cardBody_18622 text-center">
                      <p className="card-text">Ready to take off with Indigo?</p>
                      <hr />
                      <p><i className="fa fa-clock"></i> Expires 1 month 2 week</p>
                      <button className="btn btn-light w-100">Know More</button>
                    </div>
                  </div>
                </LazyLoad>
              </div>
              <div className="col-md-3 mt-2 mb-3  ">
                <LazyLoad height={290} offsetVertical={5}>
                  <div className="card" >
                    <img className="card-img-top" src="https://c4.wallpaperflare.com/wallpaper/750/566/555/costa-adeje-gran-hotel-4k-hd-computer-desktop-wallpaper-preview.jpg" alt="Card image cap" />
                    <div className="cardBody_18622 text-center">
                      <p className="card-text">Ready to take off with Indigo?</p>
                      <hr />
                      <p><i className="fa fa-clock"></i> Expires 1 month 2 week</p>
                      <button className="btn btn-light w-100">Know More</button>
                    </div>
                  </div>
                </LazyLoad>
              </div>
              <div className="col-md-3 mt-2 mb-3  ">
                <LazyLoad height={290} offsetVertical={5}>
                  <div className="card" >
                    <img className="card-img-top" src="https://i.pinimg.com/originals/b6/7b/e0/b67be0d486859ee5eda96ecd336df320.jpg" alt="Card image cap" />
                    <div className="cardBody_18622 text-center">
                      <p className="card-text">Ready to take off with Indigo?</p>
                      <hr />
                      <p><i className="fa fa-clock"></i> Expires 1 month 2 week</p>
                      <button className="btn btn-light w-100">Know More</button>
                    </div>
                  </div>
                </LazyLoad>
              </div>
              <div className="col-md-3 mt-2 mb-3  ">
                <LazyLoad height={290} offsetVertical={5}>
                  <div className="card" >
                    <img className="card-img-top" src="https://i.pinimg.com/736x/0f/b5/24/0fb524592eedc447dcdd179a00962555.jpg" alt="Card image cap" />
                    <div className="cardBody_18622 text-center">
                      <p className="card-text">Ready to take off with Indigo?</p>
                      <hr />
                      <p><i className="fa fa-clock"></i> Expires 1 month 2 week</p>
                      <button className="btn btn-light w-100">Know More</button>
                    </div>
                  </div>
                </LazyLoad>
              </div>
              <div className="col-md-3 mt-2 mb-3  ">
                <LazyLoad height={290} offsetVertical={5}>
                  <div className="card" >
                    <img className="card-img-top" src="https://wallpapershome.com/images/wallpapers/one-only-the-palm-3840x2160-dubai-best-hotels-tourism-travel-resort-4601.jpg" alt="Card image cap" />
                    <div className="cardBody_18622 text-center">
                      <p className="card-text">Ready to take off with Indigo?</p>
                      <hr />
                      <p><i className="fa fa-clock"></i> Expires 1 month 2 week</p>
                      <button className="btn btn-light w-100">Know More</button>
                    </div>
                  </div>
                </LazyLoad>
              </div>
              <div className="col-md-3 mt-2 mb-3  ">
                <LazyLoad height={290} offsetVertical={5}>
                  <div className="card" >
                    <img className="card-img-top" src="https://c4.wallpaperflare.com/wallpaper/858/551/637/hotel-terrace-chairs-ocean-maldives-hd-wallpaper-2560%C3%971440-wallpaper-preview.jpg" alt="Card image cap" />
                    <div className="cardBody_18622 text-center">
                      <p className="card-text">Ready to take off with Indigo?</p>
                      <hr />
                      <p><i className="fa fa-clock"></i> Expires 1 month 2 week</p>
                      <button className="btn btn-light w-100">Know More</button>
                    </div>
                  </div>
                </LazyLoad>
              </div>
            </div>
          </div>
          {/* 2 */}
          <div className="checkHotelOffer" id="two">
            <div className="row">
              {
                Array(8).fill().map((i) => (
                  <div className="col-md-3 mt-2 mb-3 ">
                    <div className="card" >
                      <img className="card-img-top" src="https://c4.wallpaperflare.com/wallpaper/577/1005/290/airplane-airplanes-planes-4k-wallpaper-preview.jpg" alt="Card image cap" />
                      <div className="cardBody_18622 text-center">
                        <p className="card-text">Ready to take off with Indigo?</p>
                        <hr />
                        <p><i className="fa fa-clock"></i> Expires 1 month 2 week</p>
                        <button className="btn btn-light w-100">Know More</button>
                      </div>
                    </div>
                  </div>
                ))
              }


            </div>
          </div>
          {/* 3 */}
          <div className="checkHotelOffer" id="three">
            <div className="row">
              {
                Array(8).fill().map((i) => (
                  <div className="col-md-3 mt-2 mb-3 ">
                    <div className="card" >
                      <img className="card-img-top" src="https://ak.picdn.net/shutterstock/videos/6899518/thumb/4.jpg" alt="Card image cap" />
                      <div className="cardBody_18622 text-center">
                        <p className="card-text">Ready to take off with Indigo?</p>
                        <hr />
                        <p><i className="fa fa-clock"></i> Expires 1 month 2 week</p>
                        <button className="btn btn-light w-100">Know More</button>
                      </div>
                    </div>
                  </div>
                ))
              }


            </div>
          </div>

          {/* 4 */}
          <div className="checkHotelOffer" id="four">
            <div className="row">
              {
                Array(8).fill().map((i) => (
                  <div className="col-md-3 mt-2 mb-3 ">
                    <div className="card" >
                      <img className="card-img-top" src="https://i.pinimg.com/originals/b6/7b/e0/b67be0d486859ee5eda96ecd336df310.jpg" alt="Card image cap" />
                      <div className="cardBody_18622 text-center">
                        <p className="card-text">Ready to take off with Indigo?</p>
                        <hr />
                        <p><i className="fa fa-clock"></i> Expires 1 month 2 week</p>
                        <button className="btn btn-light w-100">Know More</button>
                      </div>
                    </div>
                  </div>
                ))
              }


            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default ViewAll;
