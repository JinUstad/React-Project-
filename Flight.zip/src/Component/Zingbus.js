import React from "react";
import { useState } from "react";
import "./Zingbus.css";
function Zingbus() {
  const [toggleState, setToggleState] = useState(1);
  const [secondToggle, setsecondToggle] = useState(1);

  const toggleTab = (index) => {
    setToggleState(index);
  };

  const secondTab = (index) => {
    setsecondToggle(index);
  };
  return (
    <>
      {Array(5)
        .fill()
        .map(() => (
          <>
            <div className="zingbus mt-4">
              <div className="row">
                <div className="col-md-9">
                  <div className="wrapperZingbus122">
                    <h6>
                      Zingbus <span className="rating">4.4/5</span>{" "}
                      <span className="Rating563">563 Ratings</span>
                    </h6>
                    <p>
                      Bharat Benz Full Air Suspension AC Sleeper (2+1){" "}
                      <span className="chairBus">
                        {" "}
                        <i className="fa fa-chair ml-3"></i> 24 Seats Left
                      </span>{" "}
                      <span className="linkBus ml-3">
                        <i className="fa fa-link"></i>16 Window Seats
                      </span>
                    </p>
                    <h5>
                      22:00,
                      <span style={{ color: "gray", fontSize: "12px" }}>
                        {" "}
                        14 JUL
                      </span>{" "}
                      &#8212; 07
                      <span style={{ color: "gray", fontSize: "12px" }}>
                        hrs
                      </span>{" "}
                      35
                      <span style={{ color: "gray", fontSize: "12px" }}>
                        mins
                      </span>{" "}
                      &#8212; 05:35,{" "}
                      <span style={{ color: "gray", fontSize: "12px" }}>
                        15 JUL
                      </span>
                    </h5>
                    <hr />
                    <span className="tracingBusLive">
                      <i className="fa fa-location"></i> Live Tracing
                    </span>
                    <hr />
                    <ul>
                      <li
                        className={
                          toggleState === 1 ? "tabs active-tabs" : "tabs"
                        }
                        onClick={() => toggleTab(1)}
                      >
                        Policies
                      </li>
                      <li
                        className={
                          toggleState === 2 ? "tabs active-tabs" : "tabs"
                        }
                        onClick={() => toggleTab(2)}
                      >
                        Photo
                      </li>
                      <li
                        className={    toggleState === 3 ? "tabs active-tabs" : "tabs"
                        }
                        onClick={() => toggleTab(3)}
                      >
                        Amenities
                      </li>
                      <li
                        className={
                          toggleState === 4 ? "tabs active-tabs" : "tabs"
                        }
                        onClick={() => toggleTab(4)}
                      >
                        Pickups
                      </li>
                    </ul>
                    <div className="content-tabs">
                      <div
                        className={
                          toggleState === 1
                            ? "content  active-content"
                            : "content"
                        }
                      >
                        <div className="policies">
                          <ul>
                            <li
                              className={
                                secondToggle === 1 ? "active-tabs1" : ""
                              }
                              onClick={() => secondTab(1)}
                            >
                              CANCELLATION
                            </li>
                            <li
                              className={
                                secondToggle === 2 ? "active-tabs1" : ""
                              }
                              onClick={() => secondTab(2)}
                            >
                              CHILD PASSENGER
                            </li>
                            <li
                              className={
                                secondToggle === 3 ? "active-tabs1" : ""
                              }
                              onClick={() => secondTab(3)}
                            >
                              LUGGAGE
                            </li>
                            <li
                              className={
                                secondToggle === 4 ? "active-tabs1" : ""
                              }
                              onClick={() => secondTab(4)}
                            >
                              PICKUP TIME
                            </li>
                          </ul>
                        </div>

                        <div
                          className={
                            secondToggle === 1
                              ? "content active-content"
                              : "content"
                          }
                        >
                        <div className="row text-center">
                          <div className="col-md-4">
                            <div className="CancellationTime">
                              <p>more than 12 hrs before travel</p>
                            </div>
                          </div>
                          <div className="col-md-4">
                            <div className="Penalty">
                                <p>50%</p>
                            </div>
                          </div>
                          <div className="col-md-4">
                            <div className="Information">
                              <p>* The penalty is calculated based on total seat worth 1592</p>
                            </div>
                          </div>
                        </div>
                        </div>
                        <div
                          className={
                            secondToggle === 2
                              ? "content active-content"
                              : "content"
                          }
                        >
                          <p>&bull; Children above the age of 5 will need a ticket</p>
                        </div>
                        <div
                          className={
                            secondToggle === 3
                              ? "content active-content"
                              : "content"
                          }
                        >
                          <p>&bull; 2 pieces of luggage will be accepted free of charge per passenger. Excess items will be chargeable</p>
                          <p>&bull; Excess baggage over 20 kgs per passenger will be chargeable</p>
                        </div>
                        <div
                          className={
                            secondToggle === 4
                              ? "content active-content"
                              : "content"
                          }
                        >
                         <p>&bull; Bus operator is not obligated to wait beyond the scheduled departure time of the bus. No refund request will be entertained for late arriving passengers.</p>
                        </div>
                      </div>

                      <div
                        className={
                          toggleState === 2
                            ? "content  active-content"
                            : "content"
                        }
                      >
                        <h5 className="text-center mt-2">Could not Load</h5>
                      </div>
                      <div
                        className={
                          toggleState === 3
                            ? "content  active-content"
                            : "content"
                        }
                      >
                        <h6>Bus Amenities</h6>
                        <div className="row">
                          {Array(7)
                            .fill()
                            .map(() => (
                              <div className="col-md-3 col-4">
                                <div className="amenities">
                                  <i className="fa fa-wifi"></i>
                                  <p>wifi</p>
                                </div>
                              </div>
                            ))}
                        </div>
                      </div>

                      <div
                        className={
                          toggleState === 4
                            ? "content  active-content"
                            : "content"
                        }
                      >
                        <div className="row">
                          <div className="col-md-6">
                            <div className="pick">
                            <h5>Pickup Points</h5>
                          <p>22:00Fazalganj Chauraha, fazalganj chauraha</p>
                            </div>
                          </div>
                          <div className="col-md-6">
                            <div className="drops">
                              <h5>Drops</h5>
                                <p>05:35Anand Vihar, anand vihar </p>
                                <p>05:50Kashmiri Gate, kashmiri gate</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="col-md-3">
                  <div className="selectSeat12 text-center">
                    <div className="wrapperZingbus127">
                      <p>starting from </p>
                      <h6>
                        <strike className="prince1071">1,071</strike>{" "}
                        <span className="price1025">₹1,025</span>
                      </h6>
                      <button>Select Seat</button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </>
        ))}
    </>
  );
}

export default Zingbus;
